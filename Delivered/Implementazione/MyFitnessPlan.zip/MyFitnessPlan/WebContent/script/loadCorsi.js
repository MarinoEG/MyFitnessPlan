/**
 * Script legato alla pagina gestionecorsigestore.jsp, permette il caricamento in background
 * della lista di corsi attivi nel sistema.
 */
window.addEventListener("load", loadCorsi);

function loadCorsi(){

	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("disponibili");
			var nomi = x.getElementsByTagName("nome");
			
			var toAdd = "";
			var i = 0;
			
			
			for(i = 0; i < nomi.length; i++){
				
				toAdd += '<div class="nomecorso">\
				    <input type="submit" name="sceltacorso" value="' + nomi[i].childNodes[0].nodeValue + '">\
					</div>';
			
			}
			
			div.innerHTML = toAdd;
		}
		
	};
	
	xHttp.open("GET", "VisualizzaCorsiDisponibiliGestoreServlet", true);
	xHttp.send(null);
}