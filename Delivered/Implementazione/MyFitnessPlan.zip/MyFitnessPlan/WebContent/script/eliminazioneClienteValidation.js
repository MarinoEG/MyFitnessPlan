/**
 * Script legato alla pagina eliminacliente.jsp, controlla i form per l'inserimento della
 * password.
 */
function passwordValidation(obj){
	var password = obj.value;
	var regEx = new RegExp("^([a-zA-Z0-9@*#]{7,15})$")
	
	if(regEx.exec(password) == null)
		obj.style.borderColor = "red";
	else
		obj.style.borderColor = "lime";
}

function passwordEquality(obj){
	var password = obj.password.value;
	var passwordconferma = obj.passwordconferma.value;
		
	if(password.localeCompare(passwordconferma) != 0 || (password.localeCompare("") == 0  || passwordconferma.localeCompare("") == 0)){
		obj.password.style.borderColor = "red";
		obj.passwordconferma.style.borderColor = "red"
	}
	else{
		obj.password.style.borderColor = "lime";
		obj.passwordconferma.style.borderColor = "lime"
	}
}

function formValidation(){
	var collection = document.getElementsByTagName("input");
	var passwordborder = collection[0].style.borderColor;
	var passwordconfermaborder = collection[1].style.borderColor;
	var flag = false;
	var i = 0;
	var toAdd = "";
	
	
	if(passwordborder.localeCompare("lime") != 0)
		toAdd += "Errore nella password\n";
	
	if(passwordconfermaborder.localeCompare("lime") != 0)
		toAdd += "Errore nella conferma password\n";
	
	if(toAdd.localeCompare("") != 0){
		alert(toAdd);
		return false;
	}
	
	return true;
}