/**
 * Script legato alla pagina profilogestore.jsp, permette il caricamento in background
 * della lista di informazioni relative al gestore del sistema.
 */
window.addEventListener("load", loadInformazioniGestore);

function loadInformazioniGestore(){

	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("infogestore");
			var nome = x.getElementsByTagName("nome");
			var cognome = x.getElementsByTagName("cognome");
			var email = x.getElementsByTagName("email");
			var dataNascita = x.getElementsByTagName("dataNascita");
			var totaleIscritti = x.getElementsByTagName("totaleIscritti");
			
			var toAdd = "<table>";
			toAdd += "<tr><td>Nome: " + nome[0].childNodes[0].nodeValue + "</td></tr>";
			toAdd += "<tr><td>Cognome: " + cognome[0].childNodes[0].nodeValue + "</td></tr>";
			toAdd += "<tr><td>Email: " + email[0].childNodes[0].nodeValue + "</td></tr>";
			toAdd += "<tr><td>Data nascita: " + dataNascita[0].childNodes[0].nodeValue + "</td></tr>";
			toAdd += "<tr><td>Totale iscritti: " + totaleIscritti[0].childNodes[0].nodeValue + "</td></tr>";
			toAdd += "</table>";
			toAdd += '<a href="PaginaEliminaGestore"><input type="submit" value="Elimina"></a>';
			
			div.innerHTML = toAdd;
		}
		
	};
	
	xHttp.open("GET", "VisualizzaProfiloGestoreServlet", true);
	xHttp.send(null);
}