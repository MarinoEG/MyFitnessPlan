/**
 * Script legato alla pagina registrazione.jsp, controlla i form per l'inserimento di
 * un utente nel sistema.
 */
function nomeValidation(obj){
	var nome = obj.value;
	var regEx = new RegExp("^[a-zA-Z'-]{3,100}$");
	
	if(regEx.exec(nome) == null)
		obj.style.borderBottomColor = "red";
	else
		obj.style.borderBottomColor = "lime";
}

function cognomeValidation(obj){
	var cognome = obj.value;
	var regEx = new RegExp("^[a-zA-Z,.'-]{3,100}$");
	
	if(regEx.exec(cognome) == null)
		obj.style.borderBottomColor = "red";
	else
		obj.style.borderBottomColor = "lime";
}

function emailValidation(obj){
	var email = obj.value;
	var regEx = new RegExp("^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$");

	if(regEx.exec(email) == null)
		obj.style.borderBottomColor = "red";
	else
		obj.style.borderBottomColor = "lime";
}	

function emailEquality(obj){
	var email = obj.email.value;
	var emailconferma = obj.emailconferma.value;
	
	if(email.localeCompare(emailconferma) != 0){
		obj.email.style.borderBottomColor = "red";
		obj.emailconferma.style.borderBottomColor = "red"
	}
	else{
		obj.email.style.borderBottomColor = "lime";
		obj.emailconferma.style.borderBottomColor = "lime"
	}
}

function passwordValidation(obj){
	var password = obj.value;
	var regEx = new RegExp("^([a-zA-Z0-9@*#]{7,15})$")
	
	if(regEx.exec(password) == null)
		obj.style.borderBottomColor = "red";
	else
		obj.style.borderBottomColor = "lime";
}

function passwordEquality(obj){
	var password = obj.password.value;
	var passwordconferma = obj.passwordconferma.value;
	
	if(password.localeCompare(passwordconferma) != 0){
		obj.password.style.borderBottomColor = "red";
		obj.passwordconferma.style.borderBottomColor = "red"
	}
	else{
		obj.password.style.borderBottomColor = "lime";
		obj.passwordconferma.style.borderBottomColor = "lime"
	}
}

function formValidation(){
	var collection = document.getElementsByTagName("input");
	var toAdd = "";
	
	if(collection[0].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nel nome\n";
	if(collection[1].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nel cognome\n";
	if(collection[2].value.localeCompare("") == 0)
		toAdd += "Data nascita non inserita\n";
	if(collection[3].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nell' email\n";
	if(collection[4].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nella conferma email\n";
	if(collection[5].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nella password\n";
	if(collection[6].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nella conferma password\n";

	if(toAdd.localeCompare("") != 0){
		alert(toAdd);
		return false;
	}
	
	return true;
}