/**
 * Script legato alla pagina gestionecorsicliente.jsp, permette il caricamento in background
 * della lista di corsi attivi nel sistema, tramite ricerca in un form.
 */
function loadRicercaCorsi(){
	var nomecorso = document.getElementById("ricercaform").value;


	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("corsicercatilist");
			
			var nomi = x.getElementsByTagName("nome");
			var stato = x.getElementsByTagName("stato");
			
			var toAdd = "";

			toAdd = '<div class="listheader">\
				<span>Nome Corso</span><span>Stato Corso</span>\
				</div>';
			
			for(i = 0; i < nomi.length; i++){
				
				toAdd +='<form action="VisualizzaInfoCorsiClienteServlet" method="GET">\
					<div class="listelement">\
				    <div class="nomecorso">\
				    <input type="submit" name="sceltacorso" value="'+ nomi[i].childNodes[0].nodeValue + '">\
				    </div>\
				    <span class="stato">' + stato[i].childNodes[0].nodeValue + '</span>\
				    </div>\
					</form>';
			}
						
			div.innerHTML = toAdd;
			
		}
		
	};
	
	xHttp.open("GET", "RicercaCorsiServlet?nomericerca=" + nomecorso, true);
	xHttp.send(null);
}