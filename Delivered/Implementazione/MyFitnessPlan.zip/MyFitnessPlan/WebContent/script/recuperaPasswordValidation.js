/**
 * Script legato alla pagina recuperapassword.jsp, controlla i form per l'inserimento della
 * password.
 */
function emailValidation(obj){
	var email = obj.value;
	var regEx = new RegExp("^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$");

	if(regEx.exec(email) == null)
		obj.style.borderBottomColor = "red";
	else
		obj.style.borderBottomColor = "lime";
}	

function emailEquality(obj){
	var email = obj.email.value;
	var emailconferma = obj.emailconferma.value;
	
	if(email.localeCompare(emailconferma) != 0 || (email.localeCompare("") == 0  || emailconferma.localeCompare("") == 0)){
		obj.email.style.borderBottomColor = "red";
		obj.emailconferma.style.borderBottomColor = "red"
	}
	else{
		obj.email.style.borderBottomColor = "lime";
		obj.emailconferma.style.borderBottomColor = "lime"
	}
}

function formValidation(){
	var collection = document.getElementsByTagName("input");
	var toAdd = "";
	
	if(collection[0].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nell' email\n";
	if(collection[1].style.borderBottomColor.localeCompare("lime") != 0)
		toAdd += "Errore nella conferma email\n";

	if(toAdd.localeCompare("") != 0){
		alert(toAdd);
		return false;
	}
	
	return true;
}