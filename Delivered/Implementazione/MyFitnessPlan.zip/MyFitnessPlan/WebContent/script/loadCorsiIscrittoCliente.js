/**
 * Script legato alla pagina profilocliente.jsp, permette il caricamento in background
 * della lista di corsi attivi nel sistema a cui è iscritto lo specifico cliente. 
 */
window.addEventListener("load", loadCorsiIscrittoCliente);

function loadCorsiIscrittoCliente(){

	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("corsiiscritto");
			var nomi = x.getElementsByTagName("nome");
			
			var toAdd = "";
			var i = 0;
			
			
			for(i = 0; i < nomi.length; i++){
				
				toAdd +='<form action="VisualizzaInfoCorsiClienteServlet" method="GET">\
					<div class="listelement">\
				    <input type="submit" name="sceltacorso" value="'+ nomi[i].childNodes[0].nodeValue + '">\
				    </div>\
					</form>';
			}

			div.innerHTML = toAdd;
		}
		
	};
	
	xHttp.open("GET", "VisualizzaCorsiIscrittoClienteServlet", true);
	xHttp.send(null);
}