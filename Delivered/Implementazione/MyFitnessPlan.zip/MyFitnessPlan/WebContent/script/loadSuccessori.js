/**
 * Script legato alla pagina eliminagestore.jsp, permette il caricamento in background
 * della lista di utenti attivi nel sistema.
 */
window.addEventListener("load", loadSuccessori);

function loadSuccessori(){

	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("sceltacliente");
			var email = x.getElementsByTagName("email");
			
			var toAdd = "";
			var i = 0;

			toAdd +='<span id="nuovogestore">Scegli un nuovo gestore</span></br>';
			
			toAdd += '<input type="radio" name="nuovogestore" value="' + email[0].childNodes[0].nodeValue +'" checked> \
			<span class="emailcliente">' + email[0].childNodes[0].nodeValue + '</span></br>';
			
			for(i = 1; i < email.length; i++){
				toAdd += '<input type="radio" name="nuovogestore" value="' + email[i].childNodes[0].nodeValue +'"> \
					<span class="emailcliente">' + email[i].childNodes[0].nodeValue + '</span></br>';
				
			}
			
			div.innerHTML = toAdd;
		}
		
	};
	
	xHttp.open("GET", "VisualizzaSuccessoriGestoreServlet", true);
	xHttp.send(null);
}