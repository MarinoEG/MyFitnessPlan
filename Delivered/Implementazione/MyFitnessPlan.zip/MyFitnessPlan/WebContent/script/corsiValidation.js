/**
 * Script legato alla pagina gestionecorsigestore.jsp, controlla i form per l'inserimento di
 * un corso nel sistema.
 */
function nomeCorsoValidation(obj){
	var nomeCorso = obj.nomecorso.value;
	var regEx = new RegExp("^[a-zA-Z]{4,15}$");
	
	if(regEx.exec(nomeCorso) == null)
		obj.nomecorso.style.borderColor = "red";
	else
		obj.nomecorso.style.borderColor = "lime";
}

function nomeIstruttoreValidation(obj){
	var nomeIstruttore = obj.nomeistruttore.value;
	var regEx = new RegExp("^[a-zA-Z ,.'-]{3,100}$");
	
	if(regEx.exec(nomeIstruttore) == null)
		obj.nomeistruttore.style.borderColor = "red";
	else
		obj.nomeistruttore.style.borderColor = "lime";
}

function oraCorsoValidation(obj){
	var oraCorso = obj.value;
	var regEx = new RegExp("^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$"); 
	
	if(regEx.exec(oraCorso) == null)
		obj.style.borderColor = "red";
	else
		obj.style.borderColor = "lime";
}

function luogoCorsoValidation(obj){
	var luogoCorso = obj.value;
	var regEx = new RegExp("^[a-zA-Z]{4,15}");
	
	if(regEx.exec(luogoCorso) == null)
		obj.style.borderColor = "red";
	else
		obj.style.borderColor = "lime";
}

function prezzoValidation(obj){
	var prezzoCorso = obj.prezzo.value;
	var regEx = new RegExp("^[1-9][0-9]{0,2}(?:\.?[0-9]{3}){0,3}(.[0-9]{2})?$");
	
	if(regEx.exec(prezzoCorso) == null)
		obj.prezzo.style.borderColor = "red";
	else
		obj.prezzo.style.borderColor = "lime";
}

function formValidation(){
	var collection = document.getElementsByTagName("input");
	var flag = false;
	
	var nomeCorso = collection[0].style.borderColor;
	var nomeIstruttore = collection[1].style.borderColor;
	var etaConsigliataMin = collection[2].value;
	var etaConsigliataMax = collection[3].value;
	var dataInizio = collection[4].value;
	var numeroMaxIscritti = collection[5].value;
	var prezzo = collection[6].style.borderColor;
	
	var lunedi = collection[7].checked;
	var oraInizioLunedi = collection[8].style.borderColor;
	var oraFineLunedi =  collection[9].style.borderColor;
	var luogoLunedi =  collection[10].style.borderColor;
	
	var martedi =  collection[11].checked;
	var oraInizioMartedi = collection[12].style.borderColor;
	var oraFineMartedi =  collection[13].style.borderColor;
	var luogoMartedi =  collection[14].style.borderColor;
	
	var mercoledi =  collection[15].checked;
	var oraInizioMercoledi = collection[16].style.borderColor;
	var oraFineMercoledi =  collection[17].style.borderColor;
	var luogoMercoledi =  collection[18].style.borderColor;
	
	var giovedi =  collection[19].checked;
	var oraInizioGiovedi = collection[20].style.borderColor;
	var oraFineGiovedi =  collection[21].style.borderColor;
	var luogoGiovedi =  collection[22].style.borderColor;
	
	var venerdi =  collection[23].checked;
	var oraInizioVenerdi = collection[24].style.borderColor;
	var oraFineVenerdi =  collection[25].style.borderColor;
	var luogoVenerdi =  collection[26].style.borderColor;
	
	var sabato =  collection[27].checked;
	var oraInizioSabato = collection[28].style.borderColor;
	var oraFineSabato =  collection[29].style.borderColor;
	var luogoSabato =  collection[30].style.borderColor;
	
	if(nomeCorso.localeCompare("lime") != 0  || nomeIstruttore.localeCompare("lime") != 0 || etaConsigliataMin.localeCompare("") == 0 || etaConsigliataMax.localeCompare("") == 0 || dataInizio.localeCompare("") == 0 || numeroMaxIscritti.localeCompare("") == 0 || prezzo.localeCompare("lime")){
		flag = true;
	}
	
	if(lunedi){
		if(oraInizioLunedi.localeCompare("lime") != 0 || oraFineLunedi.localeCompare("lime") != 0 || luogoLunedi.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(martedi){
		if(oraInizioMartedi.localeCompare("lime") != 0 || oraFineMartedi.localeCompare("lime") != 0 || luogoMartedi.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(mercoledi){
		if(oraInizioMercoledi.localeCompare("lime") != 0 || oraFineMercoledi.localeCompare("lime") != 0 || luogoMercoledi.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(giovedi){
		if(oraInizioGiovedi.localeCompare("lime") != 0 || oraFineGiovedi.localeCompare("lime") != 0 || luogoGiovedi.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(venerdi){
		if(oraInizioVenerdi.localeCompare("lime") != 0 || oraFineVenerdi.localeCompare("lime") != 0 || luogoVenerdi.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(sabato){
		if(oraInizioSabato.localeCompare("lime") != 0 || oraFineSabato.localeCompare("lime") != 0 || luogoSabato.localeCompare("lime") != 0)
			flag = true;
	}
	
	if(!lunedi && !martedi && !mercoledi && !giovedi && !venerdi && !sabato)
		flag = true;
	
	if(flag){
		alert("Errore inserimento dati");
		return false;
	}
	
	return true;
}