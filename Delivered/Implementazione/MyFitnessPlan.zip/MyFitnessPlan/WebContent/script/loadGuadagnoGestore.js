/**
 * Script legato alla pagina profilogestore.jsp, permette il caricamento in background
 * della lista di gudagni per i corsi disattivati.
 */
window.addEventListener("load", loadGuadagnoGestore);

function loadGuadagnoGestore(){

	var xHttp = new XMLHttpRequest();
	xHttp.onreadystatechange = function(){
		if(xHttp.readyState==4 && xHttp.status == 200){
			var text = "";
			var i = 0;
			text = xHttp.responseText;
						
			var parser = new DOMParser();
			var x = parser.parseFromString(text, "text/xml");
			
			var div = document.getElementById("iscritti");
			var corso = x.getElementsByTagName("corso");
			var guadagno = x.getElementsByTagName("guadagno");
			
			var toAdd = "<table>";
			toAdd += "<tr><th>Nome</th><th>Guadagno</th></tr>";
			
			for(i = 0; i < corso.length; i++){
				toAdd += "<tr><td>" + corso[i].childNodes[0].nodeValue + "</td>";
				toAdd += "<td>" + guadagno[i].childNodes[0].nodeValue + "</td></tr>";
			}
			
			toAdd += "</table>";
			
			div.innerHTML = toAdd;
		}
		
	};
	
	xHttp.open("GET", "VisualizzaGuadagnoGestoreServlet", true);
	xHttp.send(null);
}