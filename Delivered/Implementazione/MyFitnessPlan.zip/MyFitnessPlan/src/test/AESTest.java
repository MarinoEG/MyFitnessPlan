package test;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import junit.framework.TestCase;
import utils.AES;

public class AESTest extends TestCase
{
	public String password;
	protected void setUp() throws Exception
	{
		password = "ciao";
	}

	protected void tearDown() throws Exception
	{
		password = null;
	}
	
	public void testEncryptDecrypt() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException
	{

		SecretKey sk = AES.getSecretKey();
		byte[] passk = new byte[100];
		passk = AES.encrypt(password, sk);
		String pass2 = AES.decrypt(passk, sk);
		assertEquals(pass2,password);
		
	}

	

}
