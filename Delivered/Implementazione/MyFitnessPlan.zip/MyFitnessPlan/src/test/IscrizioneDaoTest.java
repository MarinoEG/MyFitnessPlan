package test;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dbunit.Assertion;
import org.dbunit.DBTestCase;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.PropertiesBasedJdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.Column;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.filter.IColumnFilter;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlMetadataHandler;
import org.dbunit.operation.DatabaseOperation;

public class IscrizioneDaoTest extends DBTestCase {

	private IDataSet loadedDataSet;
	public IscrizioneDaoTest(String name)
    {
        super(name);
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_DRIVER_CLASS, "com.mysql.jdbc.Driver" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_CONNECTION_URL, "jdbc:mysql://localhost:3306/palestra" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_USERNAME, "root" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_PASSWORD, "Andrea777." );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_SCHEMA, "palestra" );
     
        
    }

	protected void setUpDatabaseConfig(DatabaseConfig config) 
	{
        config.setProperty(DatabaseConfig.PROPERTY_METADATA_HANDLER, new MySqlMetadataHandler());
        HashMap<String,String> chiavi = new HashMap<String,String>();
        chiavi.put("iscrizioni", "NomeCorso");
        config.setProperty(DatabaseConfig.PROPERTY_PRIMARY_KEY_FILTER, new MyPrimaryKeyFilter(chiavi));
	}
	@Override
	protected IDataSet getDataSet() throws Exception {
		
        loadedDataSet = new FlatXmlDataSetBuilder().build(new FileInputStream("/home/andrea/Scrivania/Iscrizioni.xml"));

        return loadedDataSet;
	}

	public void testCheckDataLoaded() throws Exception{
		
		assertNotNull(loadedDataSet);
		int rowCount = loadedDataSet.getTable("iscrizioni").getRowCount();
		assertEquals(1, rowCount);
		
	}

	protected DatabaseOperation getSetUpOperation() throws Exception
	{
		return DatabaseOperation.REFRESH;
		
	}
	
	protected DatabaseOperation getTearDownOperation() throws Exception
	{
		return DatabaseOperation.NONE;
	}
	
	class MyPrimaryKeyFilter implements IColumnFilter {
        private Map<String, String> pseudoKey = null;

        MyPrimaryKeyFilter(Map<String, String> pseudoKey) {
            this.pseudoKey = pseudoKey;
        }

        public boolean accept(String tableName, Column column) {
            return column.getColumnName().equalsIgnoreCase(pseudoKey.get(tableName));
        }

    }
}
