package test;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;

import org.dbunit.PropertiesBasedJdbcDatabaseTester;

import bean.Cliente;
import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno;
import junit.framework.TestCase;

/**Classe test per il Cliente Bean */
public class ClienteBeanTest extends TestCase 
{

	private Cliente cliente;
	
	protected void setUp()
	{
		cliente = new Cliente("ddg@live.it","Danilo","Di Giacomo",
				new byte[100],new GregorianCalendar(),
				new ArrayList<Corso>(), true);
	}
	
	protected void tearDown()
	{
		cliente = null;
	}
	
	/**Test che lancia un NullPointerException a causa della lista di clienti
	 * vuota
	 */
	public void testAggiungiCorsoIscrittoConListaGiorniNulla()
	{
		GregorianCalendar data_inizio = new GregorianCalendar(2018, 4, 22);
		Corso corso = new Corso("Nuoto", Tipo.MENSILE , data_inizio, 35, false,
				50, 10, 80, "Pasquale Jackson", null, null);
		
		try 
		{
			cliente.aggiungiCorsoIscritto(corso);
		}
		catch(NullPointerException e)
		{
			assertEquals(null, e.getMessage());
		}
	}
	
	/** Test che verifica il metodo aggiungiCorsoIscritto di CorsoBean
	 */
	public void testAggiungiCorsoIscrittoConListaGiorni() 
	{
		ArrayList<Cliente> clienti = new ArrayList<Cliente>();
		GregorianCalendar data_inizio = new GregorianCalendar(2018, 4, 22);
		Corso corso = new Corso("Nuoto", Tipo.MENSILE , data_inizio, 35, false,
				50, 10, 80, "Pasquale Jackson", clienti, new HashSet<Giorno>());
		
		cliente.aggiungiCorsoIscritto(corso);
		
		assertTrue(cliente.isIscritto(corso));
		assertTrue(corso.isClienteIscritto(cliente));
	}
	
	/** Test che verifica il metodo eliminaCorsoIscritto di CorsoBean.
	 * In questo caso con una lista vuota verrà sollevata un eccezione
	 * solo nel caso si usi il metodo isClienteIscritto
	 */
	public void testRimuoviCorsoIscrittiConListaGiorniNull() 
	{
		GregorianCalendar data_inizio = new GregorianCalendar(2018, 4, 22);
		Corso corso = new Corso("Nuoto", Tipo.MENSILE , data_inizio, 35, false,
				50, 10, 80, "Pasquale Jackson", null, null);
		
		cliente.eliminaCorsoIscritto(corso);
		
		assertFalse(cliente.isIscritto(corso));
		
		try 
		{
			assertFalse(corso.isClienteIscritto(cliente));
		}
		catch(NullPointerException e)
		{
			assertEquals(null, e.getMessage());
		}
	}
	
	/** Test del metodo equals che verifica la disuguaglianza tra due ClienteBean
	 */
	public void testEqualsConOggettiDiversi() 
	{
		cliente.setNome("Giovanni");
		cliente.setCognome("Rossi");
		cliente.setDataNascita(new GregorianCalendar(2018, 1, 28));
		cliente.setEmail("Giovanni@email.it");
		cliente.setPassword(new byte[100]);
		
		Cliente cliente2 = new Cliente();
		cliente2.setNome("Marco");
		cliente2.setCognome("Rossi");
		cliente2.setDataNascita(new GregorianCalendar(2018, 1, 28));
		cliente2.setEmail("marco@live.it");
		cliente2.setPassword(new byte[120]);
		
		assertFalse(cliente.equals(cliente2));
	}
	
	/** Test del metodo equals che verifica l'uguaglianza tra due ClienteBean
	 */
	public void testEqualsConOggettiUguali()
	{
		cliente.setNome("Giovanni");
		cliente.setCognome("Rossi");
		cliente.setDataNascita(new GregorianCalendar(2018, 1, 28));
		cliente.setEmail("giovanni@live.it");
		cliente.setPassword(new byte[100]);
		
		Cliente cliente2 = new Cliente();
		cliente2.setNome("Giovanni");
		cliente2.setCognome("Rossi");
		cliente2.setDataNascita(new GregorianCalendar(2018, 1, 28));
		cliente2.setEmail("giovanni@live.it");
		cliente2.setPassword(new byte[100]);
		
		assertTrue(cliente.equals(cliente2));
	}
}
