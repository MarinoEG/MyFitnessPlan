package test;

import java.io.FileInputStream;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;

import org.dbunit.DBTestCase;
import org.dbunit.PropertiesBasedJdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlMetadataHandler;
import org.dbunit.operation.DatabaseOperation;

import com.mysql.fabric.xmlrpc.base.Array;

import model.CorsoDao;
import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno.NomeGiorno;
import bean.Giorno;


public class CorsoDaoTest extends DBTestCase {
	private IDataSet loadedDataSet;
	public CorsoDaoTest(String name)
    {
        super(name);
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_DRIVER_CLASS, "com.mysql.jdbc.Driver" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_CONNECTION_URL, "jdbc:mysql://localhost:3306/palestra" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_USERNAME, "root" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_PASSWORD, "0000" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_SCHEMA, "palestra" );      
    }
	protected void setUpDatabaseConfig(DatabaseConfig config) {
		config.setProperty(DatabaseConfig.PROPERTY_METADATA_HANDLER, new MySqlMetadataHandler());
	}
	public void testInserisciCorsiUguali() throws Exception {
		Corso corsoTest1= new Corso("Burpees", Tipo.MENSILE, new GregorianCalendar(2018,02,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		try {
		HashSet<Giorno> x=new HashSet<>();
		Giorno giorno= new Giorno(NomeGiorno.LUNEDI, LocalTime.of(8, 30), LocalTime.of(9,30), "box", corsoTest1);
		x.add(giorno);
		corsoTest1.setGiorniCorso(x);
		CorsoDao.inserisciCorso(corsoTest1);
		Corso corsoTest2= new Corso("Burpees", Tipo.MENSILE, new GregorianCalendar(2018,02,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		HashSet<Giorno> giorni2= new HashSet<>();
		Giorno giorno2= new Giorno(NomeGiorno.MARTEDI, LocalTime.of(9,30), LocalTime.of(10, 30), "LOL", corsoTest2);
		giorni2.add(giorno2);
		corsoTest2.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest2);
		
		}catch(SQLException e) {
		
			CorsoDao.eliminaCorso(corsoTest1);
			assertEquals("Duplicate entry 'Burpees-2018-03-17-2018-04-16' for key 'PRIMARY'", e.getMessage());
		}
	}
	public void testInserisciCorsiDiversi() throws Exception{
		Corso corsoTest1= new Corso("Burpees", Tipo.MENSILE, new GregorianCalendar(2018,02,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		HashSet<Giorno> giorni1=new HashSet<>();
		Giorno giorno= new Giorno(NomeGiorno.LUNEDI, LocalTime.of(8, 30), LocalTime.of(9,30), "box", corsoTest1);
		giorni1.add(giorno);
		corsoTest1.setGiorniCorso(giorni1);
		CorsoDao.inserisciCorso(corsoTest1);
	
		Corso corsoTest2= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,04,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest2);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest2.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest2);
		
		Corso c= CorsoDao.getCorso(corsoTest1.getNome(),corsoTest1.getDataInizio(),corsoTest1.getDataFine());
		assertEquals(c.getNome(), corsoTest1.getNome());
		assertEquals(c.getDataInizio(), corsoTest1.getDataInizio());
		assertEquals(c.getDataFine(), corsoTest1.getDataFine());
		
		c=CorsoDao.getCorso(corsoTest2.getNome(), corsoTest2.getDataInizio(), corsoTest2.getDataFine());
		assertEquals(c.getNome(),corsoTest2.getNome());
		assertEquals(c.getDataInizio(), corsoTest2.getDataInizio());
		assertEquals(c.getDataFine(), corsoTest2.getDataFine());
		
		CorsoDao.eliminaCorso(corsoTest1);
		CorsoDao.eliminaCorso(corsoTest2);
	}
	public void testEliminaCorsoInesistente() throws Exception {
		try {
			Corso corsoTest= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,04,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
			Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
			HashSet<Giorno> giorni2= new HashSet<>();
			giorni2.add(giorno2);
			corsoTest.setGiorniCorso(giorni2);
			CorsoDao.inserisciCorso(corsoTest);
			
			CorsoDao.eliminaCorso(corsoTest);
			//ora il corso non � pi� bel database
		
			CorsoDao.eliminaCorso(corsoTest);
		}catch(SQLException e) {
			assertEquals(null,e.getMessage());
		}
	}
	public void testEliminaCorso() throws Exception {
		Corso corsoTest= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,04,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest);
		
		
		CorsoDao.eliminaCorso(corsoTest);
		Corso c= CorsoDao.getCorso(corsoTest.getNome(), corsoTest.getDataInizio(), corsoTest.getDataFine());
		assertEquals(null, c);
	}
	public void testGetCorsoInattivo() throws Exception{
		//essendo mensile il corso non sar� pi� attivo 
		Corso corsoTest= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,04,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		try {
			Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
			HashSet<Giorno> giorni2= new HashSet<>();
			giorni2.add(giorno2);
			corsoTest.setGiorniCorso(giorni2);
			CorsoDao.inserisciCorso(corsoTest);
			
			Corso c= CorsoDao.getCorso(corsoTest.getNome(), corsoTest.getDataInizio(), corsoTest.getDataFine());
			CorsoDao.eliminaCorso(corsoTest);
				
		} catch(SQLException e){
			
			assertEquals(null,e.getMessage());
		}
		
	}
	public void testGetCorsoInesistente() throws Exception{
		Corso corsoTest= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,04,17), 89.0, true,22, 11, 89, "davide pollio", null, null);
		try {
			Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
			HashSet<Giorno> giorni2= new HashSet<>();
			giorni2.add(giorno2);
			corsoTest.setGiorniCorso(giorni2);
			CorsoDao.inserisciCorso(corsoTest);
			CorsoDao.eliminaCorso(corsoTest);
			
			Corso c= CorsoDao.getCorso(corsoTest.getNome(), corsoTest.getDataInizio(), corsoTest.getDataFine());
			
				
		} catch(SQLException e){
			
			assertEquals(null,e.getMessage());
		}
		
	}
	public void testRicercaCorsoEsistente() throws Exception{
		Corso corsoTest= new Corso("Bombastatic", Tipo.MENSILE, new GregorianCalendar(2018,05,18), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest);
	
		List<Corso> corsiTrovati=CorsoDao.ricercaCorsi("Bombastatic");
		
		for(Corso c: corsiTrovati) {
			if(c.getNome().equals(corsoTest.getNome())) {
				assertEquals(c.getNome(), corsoTest.getNome());
				assertEquals(c.getDataInizio(), corsoTest.getDataInizio());
				assertEquals(c.getDataFine(), corsoTest.getDataFine());
			}
		}
		CorsoDao.eliminaCorso(corsoTest);
	}
	public void testRicercaCorsiWordKey() throws Exception{
		Corso corsoTest= new Corso("Arrampicata", Tipo.MENSILE, new GregorianCalendar(2018,05,18), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest);
	
		Corso corsoTest1= new Corso("Arrow", Tipo.MENSILE, new GregorianCalendar(2018,06,18), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno3 = new Giorno(NomeGiorno.MERCOLEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni3= new HashSet<>();
		giorni3.add(giorno3);
		corsoTest1.setGiorniCorso(giorni3);
		CorsoDao.inserisciCorso(corsoTest1);
		
		List<Corso> corsiTrovati=new ArrayList<>(); 
		corsiTrovati=CorsoDao.ricercaCorsi("Arr");
		
		for(Corso c: corsiTrovati) {
			if(c.getNome().equals(corsoTest.getNome())) {
				assertEquals(c.getNome().substring(0, 2), corsoTest.getNome().substring(0, 2));
			}
		}
		CorsoDao.eliminaCorso(corsoTest);
		CorsoDao.eliminaCorso(corsoTest1);
	}
	public void testRicercaCorsoInesistente() throws Exception{
		Corso corsoTest= new Corso("Arrampicata", Tipo.MENSILE, new GregorianCalendar(2018,05,18), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest);
	
		CorsoDao.eliminaCorso(corsoTest);
		
		List<Corso> corsi = CorsoDao.ricercaCorsi("Arrampicata");
		for(Corso c: corsi) {
			assertFalse(c.getNome().equalsIgnoreCase("Arrampicata"));
		}
	}
	public void testRicercaGiorniCorso() throws Exception{
		Corso corsoTest= new Corso("Arrampicata", Tipo.MENSILE, new GregorianCalendar(2018,05,18), 89.0, true,22, 11, 89, "davide pollio", null, null);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(8, 30), LocalTime.of(9, 30), "gin", corsoTest);
		HashSet<Giorno> giorni2= new HashSet<>();
		giorni2.add(giorno2);
		corsoTest.setGiorniCorso(giorni2);
		CorsoDao.inserisciCorso(corsoTest);
	
		HashSet<Giorno> giorniCorsoTest= CorsoDao.ricercaGiorniCorso(corsoTest);
		for(Giorno g:giorniCorsoTest) {
			assertEquals(g.getNome(), NomeGiorno.MARTEDI);
		}
		CorsoDao.eliminaCorso(corsoTest);
	}
	protected IDataSet getDataSet() throws Exception {
		
        loadedDataSet = new FlatXmlDataSetBuilder().build(new FileInputStream("\\Users\\simon\\Desktop\\UltimateIS\\corsi.xml"));

        return loadedDataSet;
	}
	protected DatabaseOperation getSetUpOperation() throws Exception{
		return DatabaseOperation.REFRESH;
	}
	protected DatabaseOperation getTearDownOperation() throws Exception{
		return DatabaseOperation.NONE;
	}
}
