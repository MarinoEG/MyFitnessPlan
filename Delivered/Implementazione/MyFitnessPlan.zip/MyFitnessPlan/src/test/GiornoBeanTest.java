package test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;

import bean.Cliente;
import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno;
import bean.Giorno.NomeGiorno;
import exceptions.WrongArgumentException;
import junit.framework.TestCase;

/**Classe test per il GiornoBean */
public class GiornoBeanTest extends TestCase
{

	private Giorno giorno;
	private LocalTime inizio;
	private LocalTime fine;
	private Corso corso;
	private GregorianCalendar dataInizio;
	
	protected void setUp() 
	{
		inizio = LocalTime.of(17, 30);
		fine = LocalTime.of(18, 30);
		ArrayList<Cliente> list = new ArrayList<Cliente>();
		HashSet<Giorno> set = new HashSet<Giorno>();
		dataInizio = new GregorianCalendar(2018, 4, 22);
		corso = new Corso("Piscina", Tipo.TRIMESTRALE , dataInizio, 50, false,
				50,10, 80, "Pasquale Jackson", list, set);
		giorno = new Giorno();
	}
	
	protected void tearDown() 
	{
		giorno = null;
	}
	
	/**Test che istanzia un nuovo GiornoBean
	 */
	public void testCreazioneGiorno()
	{
		giorno = new Giorno(NomeGiorno.LUNEDI, inizio, fine, "piscina", corso);
	}
	
	/**Test che cattura l'eccezione lanciata alla creazione di un GiornoBean con data di fine
	 *precendente a quella di inizio**/
	public void testCreazioneGiornoConOraFineMaggioreDiInizio() 
	{
		
		try 
		{
			giorno = new Giorno(NomeGiorno.LUNEDI, fine, inizio, "piscina", corso);
		}
		catch(WrongArgumentException e) 
		{
			assertEquals("Argomento errato", e.getMessage());
		}
	}
	
	/** Test che verifica il metodo setCorso **/
	public void testSetCorso() 
	{
		giorno = new Giorno(NomeGiorno.LUNEDI, inizio, fine, "piscina", null);
		giorno.setCorso(corso);

		assertTrue(giorno.getCorso().equals(corso));
		assertTrue(corso.isGiornoCorso(giorno));
	}
	
	/** Test che verifica il metodo setOraInizio */
	public void testSetOraInizio()
	{
		LocalTime oraInizio = LocalTime.of(17, 00);
		giorno.setOraInizio(oraInizio);
		assertEquals(oraInizio,giorno.getOraInizio());
	}
	
	/** Test che cattura l'eccezione quando viene passata una data null 
	 * al metodo setOraInizio() */
	public void testSetOraInizioNull()
	{
		LocalTime oraInizio = null;
		try
		{
			giorno.setOraInizio(oraInizio);
		}
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato", e.getMessage());
		}
		
	}
	
	/** Test che verifica il metodo setOraFine() */
	public void testSetOraFine()
	{
		LocalTime oraFine = LocalTime.of(19, 00);
		giorno.setOraFine(oraFine);
		assertEquals(oraFine,giorno.getOraFine());
	}
	
	/** Test che cattura l'eccezione quando viene passata una data null
	 *  al metodo setOraFine() */
	public void testSetOraFineNull()
	{
		LocalTime oraFine = null;
		try
		{
			giorno.setOraFine(oraFine);
		}
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato", e.getMessage());
		}
		
	}
	
	/** Test che cattura l'eccezione quando viene passata una data di fine 
	 * precedente a quella d'inizio al metodo setOraFine() */
	public void testSetOraFinePrecedenteOraInizio()
	{
		LocalTime oraFine = LocalTime.of(17, 00);
		try
		{
			giorno.setOraFine(oraFine);
			
		}
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato", e.getMessage());
		}
	}
	
	/** Test del metodo equals che verifica la disuguaglianza tra due GiornoBean
	 */
	public void testEqualsConGiorniDiversi()
	{
		giorno = new Giorno(NomeGiorno.LUNEDI, inizio, fine, "piscina", corso);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, inizio, fine, "piscina", new Corso());
		assertFalse(giorno.equals(giorno2));
	}
	
	/** Test del metodo equals che verifica l'uguaglianza tra due GiornoBean
	 */
	public void testEqualsConGiorniUguali()
	{
		giorno = new Giorno(NomeGiorno.LUNEDI, inizio, fine, "piscina", corso);
		Giorno giorno2 = new Giorno(NomeGiorno.LUNEDI, inizio, fine, "piscina", corso);
		assertTrue(giorno.equals(giorno2));
	}
}