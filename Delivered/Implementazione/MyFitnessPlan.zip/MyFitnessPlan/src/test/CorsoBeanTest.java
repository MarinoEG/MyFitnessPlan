package test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;

import bean.Cliente;
import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno;
import bean.Giorno.NomeGiorno;
import exceptions.WrongArgumentException;
import junit.framework.TestCase;

/**Classe test per il Corso Bean */
public class CorsoBeanTest extends TestCase 
{

	private Corso corso;
	private GregorianCalendar dataInizio;
	private ArrayList<Cliente> list;
	private HashSet<Giorno> set;

	protected void setUp() 
	{
		dataInizio = new GregorianCalendar(2018, 4, 22);
		corso = new Corso();
		list = new ArrayList<Cliente>();
		set = new HashSet<Giorno>();
	}
	
	protected void tearDown() 
	{
		corso = null;
	}
	
	/**Test che verfica la congruenza tra le date e il tipo forniti al
	 * costruttore di CorsoBean.
	 */
	public void testDateTipoMensile()
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
		
		GregorianCalendar data_fine = corso.getDataFine();
		
		assertEquals(2018, data_fine.get(Calendar.YEAR));
		assertEquals(5, data_fine.get(Calendar.MONTH));
		assertEquals(21, data_fine.get(Calendar.DAY_OF_MONTH));
	}
	
	/**Test che verfica la congruenza tra le date e il tipo forniti al
	 * costruttore di CorsoBean.
	 */
	public void testDateTipoTrimestrale() 
	{
		corso = new Corso("Nuoto", Tipo.TRIMESTRALE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
		
		GregorianCalendar data_fine = corso.getDataFine();
		
		assertEquals(2018, data_fine.get(Calendar.YEAR));
		assertEquals(7, data_fine.get(Calendar.MONTH));
		assertEquals(20, data_fine.get(Calendar.DAY_OF_MONTH));
	}
	
	/**Test che verfica la congruenza tra le date e il tipo forniti al
	 * costruttore di CorsoBean.
	 */
	public void testDateTipoSemestrale() 
	{
		corso = new Corso("Nuoto", Tipo.SEMESTRALE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
		
		GregorianCalendar data_fine = corso.getDataFine();
		
		assertEquals(2018, data_fine.get(Calendar.YEAR));
		assertEquals(10, data_fine.get(Calendar.MONTH));
		assertEquals(18, data_fine.get(Calendar.DAY_OF_MONTH));
	}
	
	/**Test che lancia un WrongArgumentException per la mancanza del
	 * tipo nel costruttore.
	 */
	public void testDateSenzaTipo() 
	{
		
		try 
		{
			corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
					75, 10, 80, "Pasquale Jackson", null, null);
		}
		catch(WrongArgumentException e) 
		{
			assertEquals("Argomento errato", e.getMessage());
		}
	}
	
	/**Test che lancia un WrongArgumentException poich� l'et�consigliata min
	 * inserita � maggiore dell'et� consigliata max
	 */
	public void testSetEtaConsigliataMin() 
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
	
		try 
		{
			corso.setEtaConsigliataMin(81);
		}
		catch(WrongArgumentException e) 
		{
			assertEquals("Argomento errato", e.getMessage());
		}
	}
	
	/**Test che lancia un WrongArgumentException poich� l'et� consigliata max
	 * inserita � minore dell'et�consigliata min
	 */
	public void testSetEtaConsigliataMax() 
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
	
		try 
		{
			corso.setEtaConsigliataMax(9);
		}
		catch(WrongArgumentException e) 
		{
			assertEquals("Argomento errato", e.getMessage());
		}
	}
	
	/**Test che verifica il metodo AggiungiClienteIscritto, lancia un
	 * NullPointerException a causa della mancanza della lista clienti
	 */
	public void testAggiuntaClienteSenzaListaClienti() 
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", null, null);
	
		Cliente cliente = new Cliente();
		cliente.setNome("Giovanni");
		cliente.setCognome("Rossi");
		cliente.setDataNascita(new GregorianCalendar(2018, 1, 30));
		cliente.setEmail("giovanni@live.it");
		cliente.setPassword(new byte[100]);
		
		try 
		{
			corso.aggiungiClienteIscritto(cliente);
		}
		catch(NullPointerException e) 
		{
			assertEquals(null, e.getMessage());
		}
	}
	
	/**Test che verifica il metodo AggiungiGiorno
	 */
	public void testAggiuntaGiorno() 
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", list, set);
	
		Cliente cliente = new Cliente();
		cliente.setNome("Giovanni");
		cliente.setCognome("Rossi");
		cliente.setDataNascita(new GregorianCalendar(2018, 1, 30));
		cliente.setEmail("Giovanni@email.it");
		cliente.setPassword(new byte[100]);
		
		Giorno giorno = new Giorno(NomeGiorno.LUNEDI,
				LocalTime.of(19, 45),LocalTime.of(21, 15),
				"Piscina", null);
		corso.aggiungiGiorno(giorno);
		
		assertTrue(corso.isGiornoCorso(giorno));
		assertTrue(giorno.getCorso().equals(corso));
	}
	
	/**Test che verifica il metodo RimuoviGiorno
	 */
	public void testEliminaGiorno() 
	{
		list = new ArrayList<Cliente>();
		set = new HashSet<Giorno>();
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", list, set);
	
		Cliente cliente = new Cliente();
		cliente.setNome("Giovanni");
		cliente.setCognome("Rossi");
		cliente.setDataNascita(new GregorianCalendar(2018, 1, 30));
		cliente.setEmail("giovanni@live.it");
		cliente.setPassword(new byte[100]);
		
		Giorno giorno = new Giorno(NomeGiorno.LUNEDI,
				LocalTime.of(19, 45),LocalTime.of(21, 15),
				"Piscina", null);
		corso.aggiungiGiorno(giorno);
		
		corso.eliminaGiorno(giorno);
		assertFalse(corso.isGiornoCorso(giorno));
		assertTrue(giorno.getCorso() == null);
	}
	
	/** test del metodo setDataInizio() */
	public void testSetDataInizio()
	{
		dataInizio = new GregorianCalendar(2018,1,22);
		corso.setDataInizio(dataInizio);
		assertTrue(dataInizio.equals(corso.getDataInizio()));
	}

	/** test del metodo setDataInizio() che lancia una WrongArgumentException 
	 *  perch� dataFine!=null
	 */
	
	public void testSetDataInizioConDataFineNotNull()
	{
		GregorianCalendar dataFine = new GregorianCalendar(2018,5,22);
		corso.setDataFine(dataFine);
		
		try
		{
			dataInizio = new GregorianCalendar(2018,1,22);
			corso.setDataInizio(dataInizio);
		}
		
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato",e.getMessage());
		}
	}
	
	/** test del metodo setDataInizio() che lancia una WrongArgumentException 
	 *  perch� dataInizio!=null
	 */
	
	public void testSetDataInizioConDataInizioGiaSettata()
	{
		GregorianCalendar dataInizio2 = new GregorianCalendar(2018,5,22);
		corso.setDataInizio(dataInizio2);
		
		try
		{
			dataInizio = new GregorianCalendar(2018,1,22);
			corso.setDataInizio(dataInizio);
		}
		
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato",e.getMessage());
		}
	}
	
	/** test del metodo setDataFine() */
	
	public void testSetDataFine()
	{
		GregorianCalendar dataFine = new GregorianCalendar(2018,4,22);
		corso.setDataFine(dataFine);
		assertEquals(dataFine,corso.getDataFine());
	}
	
	/** test del metodo setDataFine() che lancia una WrongArgumentException 
	 *  perch� dataInizio!=null
	 */
	
	public void testSetDataFineConDataInizioNotNull()
	{
		dataInizio = new GregorianCalendar(2018,1,22);
		corso.setDataInizio(dataInizio);
		
		try
		{
			GregorianCalendar dataFine = new GregorianCalendar(2018,4,22);
			corso.setDataFine(dataFine);
		}
		
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato",e.getMessage());
		}
	}
	
	/** test del metodo setDataFine() che lancia una WrongArgumentException 
	 *  perch� dataFine!=null
	 */
	
	public void testSetDataFineConDataFineGiaSettata()
	{
		GregorianCalendar dataFine = new GregorianCalendar(2018,5,22);
		corso.setDataFine(dataFine);
		
		try
		{
			dataFine = new GregorianCalendar(2018,1,22);
			corso.setDataFine(dataFine);
		}
		
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato",e.getMessage());
		}
	}
	
	/** test del metodo setGiorniCorso() */
	
	public void testSetGiorniCorso()
	{
		HashSet<Giorno> giorni = new HashSet<Giorno>();
		Giorno giorno = new Giorno(NomeGiorno.LUNEDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		giorni.add(giorno);
		corso.setGiorniCorso(giorni);
		assertEquals(giorni,corso.getGiorniCorso());
	}
	
	/** test del metodo setGiornoCorso(), lancia una WrongArgumentException()
	 * perch� l'hashset passato ha pi� di 6 elementi
	 */
	
	public void testSetGiorniCorsoConHashSetTroppoGrande()
	{
		HashSet<Giorno> giorni = new HashSet<Giorno>();
		Giorno giorno1 = new Giorno(NomeGiorno.LUNEDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno2 = new Giorno(NomeGiorno.MARTEDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno3 = new Giorno(NomeGiorno.MERCOLEDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno4 = new Giorno(NomeGiorno.GIOVEDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno5 = new Giorno(NomeGiorno.VENERDI, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno6 = new Giorno(NomeGiorno.SABATO, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		Giorno giorno7 = new Giorno(NomeGiorno.DOMENICA, LocalTime.of(19, 45), LocalTime.of(21, 15), "Nuoto", corso);
		giorni.add(giorno1);
		giorni.add(giorno2);
		giorni.add(giorno3);
		giorni.add(giorno4);
		giorni.add(giorno5);
		giorni.add(giorno6);
		giorni.add(giorno7);
		
		try
		{
			corso.setGiorniCorso(giorni);
		}
		
		catch(WrongArgumentException e)
		{
			assertEquals("Argomento errato",e.getMessage());
		}
	}
	
	/** test del metodo equals() con due oggetti CorsoBean uguali */
	
	public void testEquals()
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", list, set);
		Corso corso2 = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", list, set);
		assertTrue(corso.equals(corso2));
	}
	
	/** test del metodo equals() con due oggetti CorsoBean diversi */
	public void testEqualsConDueOggettiDiversi()
	{
		corso = new Corso("Nuoto", Tipo.MENSILE , dataInizio, 35, false,
				75, 10, 80, "Pasquale Jackson", list, set);
		Corso corso2 = new Corso("Crossfit", Tipo.SEMESTRALE , dataInizio, 60, true,
				50, 16, 50, "Pasquale Jackson", list, set);
		assertFalse(corso.equals(corso2));
	}
	
	
}
