package test;

import java.util.ArrayList;
import java.util.GregorianCalendar;

import bean.Cliente;
import bean.Corso;
import junit.framework.TestCase;
import utils.SendMailTLSFacade;

public class SendMailTLSFacadeTest extends TestCase {

	private String dest;
	private String nome;
	private String password;
	
	protected void setUp()
	{
		dest = "A.Montefusco20@studenti.unisa.it";
		nome = "Andrea";
		password = "Password";
	}
	
	protected void tearDown()
	{
		dest = null;
		nome = null;
		password = null;
	}
	
	public void testSendMail() {
		assertTrue(SendMailTLSFacade.sendMail(dest, nome, password));
	}
}
