package test;

import java.io.File;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import bean.Cliente;
import bean.Corso;
import junit.framework.TestCase;
import utils.EncryptionFacade;

public class EncryptionFacadeTest extends TestCase {

	private EncryptionFacade ef;
	private String email;
	private String password;
	private byte[] b;
	
	protected void setUp()
	{
		ef = new EncryptionFacade("/home/andrea/Scrivania/testFacade.dat");
		email = "email@email.it";
		password = "prova";
	}
	
	protected void tearDown()
	{
		ef = null;
		email = null;
		password = null;
	}
	
	public void testEncrypt() {
		
		try {
			b = ef.encrypt(email, password);
			assertEquals(b.length, 16);
			
			ef.save();
			
			File file = new File("/home/andrea/Scrivania/testFacade.dat");
			assertTrue(file.exists());
			
			String pass = ef.decrypt(email, b);
			assertEquals(pass, password);
				
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
