package test;

import java.io.FileInputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import org.dbunit.DBTestCase;
import org.dbunit.PropertiesBasedJdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlMetadataHandler;
import org.dbunit.operation.DatabaseOperation;

import bean.Cliente;
import bean.Corso;
import model.ClienteDao;

public class ClienteDaoTest extends DBTestCase {

	private IDataSet loadedDataSet;
	private Cliente cliente;
	
	public ClienteDaoTest(String name)
    {
        super(name);
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_DRIVER_CLASS, "com.mysql.jdbc.Driver" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_CONNECTION_URL, "jdbc:mysql://localhost:3306/palestra" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_USERNAME, "root" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_PASSWORD, "0000" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_SCHEMA, "palestra" );
        
        cliente = new Cliente("ddg@live.it","Danilo","Di Giacomo",
				new byte[100],new GregorianCalendar(),
				new ArrayList<Corso>(), true);
    }

	/**protected void setUpDatabaseConfig(DatabaseConfig config) {
        config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new OracleDataTypeFactory());
    }**/
	
	protected void setUpDatabaseConfig(DatabaseConfig config) {
		config.setProperty(DatabaseConfig.PROPERTY_METADATA_HANDLER, new MySqlMetadataHandler());
	}
	
	@Override
	protected IDataSet getDataSet() throws Exception {
		
        loadedDataSet = new FlatXmlDataSetBuilder().build(new FileInputStream("\\Users\\simon\\Desktop\\UltimateIS\\Cliente.xml"));

        return loadedDataSet;
	}

	public void testCheckDataLoaded() throws Exception{
		
		assertNotNull(loadedDataSet);
		int rowCount = loadedDataSet.getTable("utenti").getRowCount();
		assertEquals(1, rowCount);
	}
	
	public void testVerificaUtenteInserito() {
		
		Cliente cl = null;
		
		try {
			ClienteDao.inserisciUtente(cliente);
			cl = ClienteDao.getCliente(cliente.getEmail());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		assertEquals(cl.getEmail(), cliente.getEmail());
		assertEquals(cl.getNome(), cliente.getNome());
		assertEquals(cl.getCognome(), cliente.getCognome());
		assertEquals(cl.getStato(), cliente.getStato());
	}
	
	public void testVerificaUtenteEliminato() {
		
		Cliente cl = null;
		
		try {
			ClienteDao.eliminaCliente(cliente);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			cl = ClienteDao.getCliente(cliente.getEmail());
		} catch (SQLException e) {
			assertEquals(null, e.getMessage());
		}
		
	}
	
	public void testOttieniClientiAttivi() {
		
		ArrayList<Cliente> clientiList = null;
		int numeroClientiAttivi = 0;
		try {
			clientiList = ClienteDao.getClienti();
			numeroClientiAttivi = ClienteDao.getNumClienti();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		assertTrue(clientiList.size() == numeroClientiAttivi);
	}
	
	public void testOttieniClientiInattivi() {
		
		ArrayList<Cliente> clientiList = null;
		int numeroClientiAttivi = 0;
		
		try {
			clientiList = ClienteDao.getClientiInattivi();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		assertTrue(clientiList.size() >= 1);
		
	}
	
	public void testRipristinaAccount() {
		
		Cliente cl = null;
		
		try {
			ClienteDao.ripristinaAccount(cliente.getEmail(), cliente.getPassword());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			cl = ClienteDao.getCliente(cliente.getEmail());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		assertEquals(cl.getEmail(), cliente.getEmail());
		assertEquals(cl.getNome(), cliente.getNome());
		assertEquals(cl.getCognome(), cliente.getCognome());
		assertEquals(cl.getStato(), cliente.getStato());
	
		try {
			ClienteDao.eliminaCliente(cliente);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected DatabaseOperation getSetUpOperation() throws Exception
    {
        return DatabaseOperation.REFRESH;
    }

    protected DatabaseOperation getTearDownOperation() throws Exception
    {
        return DatabaseOperation.NONE;
    }
	
}
