package test;

import java.util.GregorianCalendar;

import bean.Gestore;
import junit.framework.TestCase;

/**Classe test per il GestoreBean */
public class GestoreBeanTest extends TestCase 
{

	private Gestore gestore;
	
	protected void setUp() 
	{
		gestore = null;
	}
	
	protected void tearDown() 
	{
		gestore = null;
	}
	
	/** Test del metodo getInstance() **/
	public void testCreazioneGestore() 
	{
		gestore = Gestore.getInstance();
	}
	
	/** Test che verifica che getInstance restituisca sempre la stessa istanza di GestoreBean **/
	public void testIstanzeGestore() 
	{
		gestore = Gestore.getInstance();
		gestore.setNome("Francesco");
		gestore.setCognome("Florenzi");
		gestore.setDataNascita(new GregorianCalendar(2018, 21, 3));
		gestore.setEmail("floresco@live.it");
		gestore.setPassword(new byte[100]);

		Gestore gestore1 = Gestore.getInstance();
		
		assertTrue(gestore.getNome().equals(gestore1.getNome()));
		assertTrue(gestore.getCognome().equals(gestore1.getCognome()));
		assertTrue(gestore.getDataNascita().equals(gestore1.getDataNascita()));
		assertTrue(gestore.getEmail().equals(gestore1.getEmail()));
		assertTrue(gestore.getPassword().equals(gestore1.getPassword()));
	}
	
	/** Test che confronta istanze di GestoreBean null **/
	public void testIstanzeGestoreConNull() 
	{
		gestore = Gestore.getInstance();
		
		Gestore gestore1 = Gestore.getInstance();
		
		assertTrue(gestore.getNome().equals(gestore1.getNome()));
		assertTrue(gestore.getCognome().equals(gestore1.getCognome()));
		assertTrue(gestore.getDataNascita().equals(gestore1.getDataNascita()));
		assertTrue(gestore.getEmail().equals(gestore1.getEmail()));
		assertTrue(gestore.getPassword().equals(gestore1.getPassword()));
	}
}
