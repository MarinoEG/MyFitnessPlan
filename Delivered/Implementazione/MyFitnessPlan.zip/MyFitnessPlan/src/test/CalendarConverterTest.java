package test;

import java.util.Calendar;
import java.util.GregorianCalendar;

import junit.framework.TestCase;
import utils.CalendarConverter;

public class CalendarConverterTest extends TestCase 
{
	GregorianCalendar data1;
	GregorianCalendar data2;
	protected void setUp() throws Exception
	{
		data1 = new GregorianCalendar();
		data1.set(2018, 01, 05);
		data2 = new GregorianCalendar();
		data2.set(1996, 11, 27);
	}

	protected void tearDown() throws Exception 
	{
		data1 = null;
		data2 = null;
	}
	
	public void testEtaConverter()
	{
		int anno = 0;
		anno = CalendarConverter.etaConverter(data1, data2);
		int anno2 = 0;
		anno2 = data1.get(Calendar.YEAR)-data2.get(Calendar.YEAR) ;
		if(data1.get(Calendar.MONTH) > data2.get(Calendar.MONTH)||
			(data1.get(Calendar.MONTH) == data2.get(Calendar.MONTH)
			&& data1.get(Calendar.DAY_OF_MONTH) < data2.get(Calendar.DAY_OF_MONTH)))
		{
			anno2 --;
		}
		
		
		assertEquals(anno,anno2);
	}

}
