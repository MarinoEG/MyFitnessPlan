package test;

import java.io.FileInputStream;
import java.sql.SQLException;
import java.util.GregorianCalendar;

import org.dbunit.DBTestCase;
import org.dbunit.DatabaseUnitException;
import org.dbunit.PropertiesBasedJdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlMetadataHandler;
import org.dbunit.operation.DatabaseOperation;

import bean.Cliente;
import bean.Gestore;
import model.ClienteDao;
import model.GestoreDao;

public class GestoreDaoTest extends DBTestCase {

	private IDataSet loadedDataSet;
	private Cliente cliente;
	
	public GestoreDaoTest(String name)
    {
        super(name);
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_DRIVER_CLASS, "com.mysql.jdbc.Driver" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_CONNECTION_URL, "jdbc:mysql://localhost:3306/palestra" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_USERNAME, "root" );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_PASSWORD, "Andrea777." );
        System.setProperty( PropertiesBasedJdbcDatabaseTester.DBUNIT_SCHEMA, "palestra" );
        
        cliente = new Cliente();
        cliente.setEmail("ges@live.it");
        cliente.setNome("Danilo");
        cliente.setCognome("Di Giacomo");
        cliente.setPassword(new byte[100]);
        cliente.setDataNascita(new GregorianCalendar());
        cliente.setStato(true);
    }

	/**protected void setUpDatabaseConfig(DatabaseConfig config) {
    config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new OracleDataTypeFactory());
    }**/

	protected void setUpDatabaseConfig(DatabaseConfig config) {
		config.setProperty(DatabaseConfig.PROPERTY_METADATA_HANDLER, new MySqlMetadataHandler());
	}
	
	protected IDataSet getDataSet() throws Exception {
		
        loadedDataSet = new FlatXmlDataSetBuilder().build(new FileInputStream("/home/andrea/Scrivania/Cliente.xml"));

        return loadedDataSet;
	}

	public void testCheckDataLoaded() throws Exception{
		
		assertNotNull(loadedDataSet);
		int rowCount = loadedDataSet.getTable("utenti").getRowCount();
		assertEquals(1, rowCount);
	}
	
	public void testEliminaModificaGestore() {
		
		Gestore gestore = null;
		Cliente cl = null;
				
		try {
			ClienteDao.inserisciUtente(cliente);
			cl = ClienteDao.getCliente(cliente.getEmail());
			assertEquals(cliente.getEmail(), cl.getEmail());
			assertTrue(cl.getStato());
			
			GestoreDao.setGestore(cliente);
			
			gestore = Gestore.getInstance();
			gestore.setEmail(cliente.getEmail());
			GestoreDao.eliminaGestore(gestore);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected DatabaseOperation getSetUpOperation() throws Exception
    {
        return DatabaseOperation.REFRESH;
    }

    protected DatabaseOperation getTearDownOperation() throws Exception
    {
        return DatabaseOperation.NONE;
    }
    
    
}
