package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import connessione.DriveManagerConnectionPool;
import bean.Cliente;

/**
 * Classe che fornisce metodi per le operazioni relative alla tabella utenti del database, in
 * particolare quelle relative ai clienti.
 * @author Marino Iannacchero
 * @version 2.0
 */
public class ClienteDao 
{
	/**
	 * Metodo che permettere di inserire l'utente passato come parametro
	 * nella tabella utenti nel database.
	 * @param cliente Cliente da inserie nel database.
	 */
	public static synchronized void inserisciUtente(Cliente cliente) throws SQLException
	{
		Connection con = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERISCI_CLIENTE);
			
			ps.setString(1,cliente.getEmail());
			ps.setDate(2, new Date(cliente.getDataNascita().getTimeInMillis()));
			ps.setString(3,cliente.getNome());
			ps.setString(4, cliente.getCognome());
			ps.setBytes(5, cliente.getPassword());
			ps.setString(6, "cliente");
			ps.setBoolean(7, cliente.getStato());
			ps.executeUpdate();
			
			ps.close();
		}	
			catch (SQLException sqlException) 
			{
				throw sqlException;
			}
			finally 
			{
				DriveManagerConnectionPool.releaseConnection(con);
			}
			
			
	}
	
	/**
	 * Metodo che restituisce un oggetto Cliente recuperandolo dal database, a ogni cliente
	 * è associata un'email.
	 * @param email email relativa all'utente da cercare
	 * @return oggetto Cliente associato all'email.
	 * @throws SQLException
	 */
	public static synchronized Cliente getCliente(String email) throws SQLException
	{
		Connection con = null;
		Cliente cliente = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(RICERCA_CLIENTE);
			ps.setString(1, email);
			ps.setBoolean(2, true);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				cliente = new Cliente();
				cliente.setEmail(rs.getString("Email"));
				cliente.setNome(rs.getString("Nome"));
				cliente.setCognome(rs.getString("Cognome"));
				cliente.setPassword(rs.getBytes("Password"));
				Date dataLetta = rs.getDate("DataNascita");
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(dataLetta);
				cliente.setDataNascita(dataNascita);
				cliente.setStato(rs.getBoolean("Stato"));
			}
			rs.close();
			ps.close();
		}	
			catch (SQLException sqlException) 
			{
				throw sqlException;
			}
			finally 
			{
				DriveManagerConnectionPool.releaseConnection(con);
			}
			
		return cliente;
			
	}
	
	/**
	 * Metodo che disattiva l'account di un Cliente nel database in base ai parametri contenuti
	 * nell'oggetto cliente.
	 * @param cliente cliente da eliminate dal database.
	 */
	public static synchronized void eliminaCliente(Cliente cliente) throws SQLException 
	{
		Connection con = null;
		
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
	
			PreparedStatement ps = con.prepareStatement(ELIMINA_CLIENTE);
			ps.setBoolean(1, false);
			ps.setString(2, cliente.getEmail());
	
			ps.executeUpdate();
			
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che restituisce la lista di clienti attivi presenti nel database.
	 * @return lista di clienti presenti nel database.
	 */
	public static synchronized ArrayList<Cliente> getClienti() throws SQLException
	{
		Connection con = null;
		Cliente cliente = null;
		ArrayList<Cliente> clienti = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_CLIENTI);
			ps.setString(1,"cliente");
			ps.setBoolean(2,true);
			ResultSet rs = ps.executeQuery();
			clienti = new ArrayList<Cliente>();
			while(rs.next())
			{
				
				cliente = new Cliente();
				cliente.setEmail(rs.getString("Email"));
				cliente.setNome(rs.getString("Nome"));
				cliente.setCognome(rs.getString("Cognome"));
				cliente.setPassword(rs.getBytes("Password"));
				Date dataLetta = rs.getDate("DataNascita");
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(dataLetta);
				cliente.setDataNascita(dataNascita);
				cliente.setStato(rs.getBoolean("Stato"));
				clienti.add(cliente);
			}
			rs.close();
			ps.close();
		}	
			catch (SQLException sqlException) 
			{
				throw sqlException;
			}
			finally 
			{
				DriveManagerConnectionPool.releaseConnection(con);
			}
			
		return clienti;
			
	}
	
	/**
	 * Metodo che fornisce il numero di utenti attivi presenti nel database.
	 * @return Il numero di utenti attivi.
	 */
	public static synchronized int getNumClienti() throws SQLException
	{
		Connection con = null;
		int i = 0 ;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_NUMERO_CLIENTI);
			ps.setString(1,"cliente");
			ps.setBoolean(2, true);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				i = rs.getInt("COUNT(Tipo)");
			}
			
			
			rs.close();
			ps.close();
		}	
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
			
		return i ;
		
			
	}
	
	/**
	 * Metodo che fornisce la lista di clienti inattivi presenti nel database.
	 * @return Lista contenente i clienti inattivi.
	 * @throws SQLException
	 */
	public static synchronized ArrayList<Cliente> getClientiInattivi() throws SQLException
	{
		Connection con = null;
		Cliente cliente = null;
		ArrayList<Cliente> clienti = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(GET_CLIENTI);
			ps.setString(1,"cliente");
			ps.setBoolean(2,false);
			ResultSet rs = ps.executeQuery();
			clienti = new ArrayList<Cliente>();
			while(rs.next())
			{
				
				cliente = new Cliente();
				cliente.setEmail(rs.getString("Email"));
				cliente.setNome(rs.getString("Nome"));
				cliente.setCognome(rs.getString("Cognome"));
				cliente.setPassword(rs.getBytes("Password"));
				Date dataLetta = rs.getDate("DataNascita");
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(dataLetta);
				cliente.setDataNascita(dataNascita);
				cliente.setStato(rs.getBoolean("Stato"));
				clienti.add(cliente);
			}
			rs.close();
			ps.close();
		}	
			catch (SQLException sqlException) 
			{
				throw sqlException;
			}
			finally 
			{
				DriveManagerConnectionPool.releaseConnection(con);
			}
			
		return clienti;
			
	}
	
	/**
	 * Metodo che riattiva l'utente associato all'email, cambiando il suo stato nel database.
	 * @param email email dell'utente a cui sarà cambiato lo stato.
	 * @param password password dell'utente.
	 */
	public static synchronized void ripristinaAccount(String email,byte[] password) throws SQLException
	{
	Connection con = null;
		
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
	
			PreparedStatement ps = con.prepareStatement(RIPRISTINA_CLIENTE);
			ps.setBoolean(1, true);
			ps.setString(2, email);
			ps.setBytes(3, password);
			ps.setString(4, "cliente");
			
			ps.executeUpdate();
			
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	private static final String TABELLA_UTENTE = "palestra.utenti";
	private static final String INSERISCI_CLIENTE = "INSERT INTO " + TABELLA_UTENTE
		     + " VALUES (?, ?, ?, ?, ?, ?, ?)";
	private static final String RICERCA_CLIENTE = "SELECT *" + " FROM " + TABELLA_UTENTE 
			 + " WHERE Email=? AND Stato=?";
	private static final String ELIMINA_CLIENTE = "UPDATE " + TABELLA_UTENTE 
			 + " SET Stato=? WHERE Email=?";
	private static final String GET_CLIENTI = "SELECT * FROM " + TABELLA_UTENTE
			+ " WHERE Tipo=? AND Stato=?";
	private static final String GET_NUMERO_CLIENTI = "SELECT COUNT(Tipo) FROM "+ TABELLA_UTENTE
								+ " WHERE Tipo=? AND Stato=?";
	private static final String RIPRISTINA_CLIENTE = "UPDATE " + TABELLA_UTENTE
			+ " SET Stato=? WHERE Email=? AND Password=? AND Tipo=?";
}
