package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import bean.Cliente;
import bean.Corso;
import connessione.DriveManagerConnectionPool;

/**
 * Classe che fornisce metodi per le operazioni relative alla tabella iscrizioni del database.
 * @author Marino Iannacchero
 * @version 2.0
 */
public class IscrizioneDao 
{
	/**
	 * Metodo che permette di iscrivere un cliente a un corso.
	 * @param emailUtente Email dell'utente da iscrivere.
	 * @param nomeCorso Nome del corso a cui l'utente verrà iscritto.
	 * @param dataInizioCorso Oggetto rappresentante la data di inizio del corso.
	 * @param dataFineCorso Oggetto rappresentante la data di fine del corso.
	 */
	public static synchronized void inserisciIscrizione(String emailUtente,String nomeCorso,GregorianCalendar dataInizioCorso,GregorianCalendar dataFineCorso) throws SQLException
	{
		Connection con = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERISCI_ISCRIZIONE);
			
			ps.setString(1, emailUtente);
			ps.setString(2, nomeCorso);
			ps.setDate(3,new Date(dataInizioCorso.getTimeInMillis()));  
			ps.setDate(4,new Date(dataFineCorso.getTimeInMillis()));
			ps.executeUpdate();
			
			ps.close();
		}	
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
			
	}

	/**
	 * Metodo che restituisce un insieme rappresentante le coppie corso-guadagno, ovvero
	 * il guadagno totale dei corsi inattivi presenti nel database.
	 * @return Insieme con coppie guadagno corso.
	 * @throws SQLException
	 */
	public static synchronized Map<String,Double> getGuadagni() throws SQLException
	{
		
		Connection con = null;
		Map<String,Double> guadagni = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_GUADAGNI);
			ps.setBoolean(1, false);
			ResultSet rs = ps.executeQuery();
			guadagni = new HashMap<String,Double>();
			
			while(rs.next())
			{
				guadagni.put(rs.getString("Nome"), rs.getDouble("SUM(Costo)"));
			}
			
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return guadagni;
	}
	
	/**
	 * Metodo che restituisce il costo totale dei corsi attivi a cui il cliente e' iscritto.
	 * @param cliente Cliente del quale si vogliono conoscere i costi.
	 * @return costo dei corsi attivi a cui è iscritto il cliente.
	 */
	public static synchronized double getCostiCliente(Cliente cliente) throws SQLException
	{
		Connection con = null;
		double costo = 0;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_COSTI);
			ps.setBoolean(1, true);
			ps.setString(2, cliente.getEmail());
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				costo = rs.getDouble("SUM(corsi.Costo)");
			}
			
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return costo;
	}
	
	/**
	 * Metodo che restituisce la data di fine del primo corso a terminare temporalmente.
	 * @return data di fine del primo corso a terminare.
	 */
	public static synchronized GregorianCalendar getDataPrimoCorso() throws SQLException
	{
		Connection con = null;
		GregorianCalendar data = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_DATA_PRIMO_CORSO);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				data = new GregorianCalendar();
				Date data1 = rs.getDate("DataFine");
				data.setTime(data1);
			}
			
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return data;
	}
	
	/**
	 * Metodo che restituisce la lista dei clienti iscritti al corso passato come parametro. 
	 * @param corso Oggetto rappresentante il corso di cui si vuole conosce la lista di clienti.
	 * @return Lista di clienti iscritti al corso.
	 */
	public static synchronized ArrayList<Cliente> getClientiCorso(Corso corso) throws SQLException
	{
		Connection con = null;
		ArrayList<Cliente> clienti = null;
		Cliente cliente = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_CLIENTI_CORSO);
			clienti = new ArrayList<Cliente>();
			ps.setString(1, corso.getNome());
			ps.setDate(2, new Date(corso.getDataInizio().getTimeInMillis()));
			ps.setDate(3, new Date(corso.getDataFine().getTimeInMillis()));
			ps.setBoolean(4,true);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				cliente = new Cliente();
				cliente.setNome(rs.getString("utenti.Nome"));
				cliente.setCognome(rs.getString("utenti.Cognome"));
				Date data = rs.getDate("utenti.DataNascita");
				GregorianCalendar dataNascita = new GregorianCalendar();
				dataNascita.setTime(data);
				cliente.setDataNascita(dataNascita);
				clienti.add(cliente);
			}
			
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return clienti;
	}
	
	/**
	 * Metodo che restituisce la lista di email dei clienti iscritti al corso passato come
	 * parametro.
	 * @param corso Oggetto rappresentante il corso del quale si vuole conoscere la lista
	 * di email degli iscritti.
	 * @return
	 * @throws SQLException
	 */
	public static synchronized ArrayList<Cliente> getInfoClientiCorso(Corso corso) throws SQLException
	{
		Connection con = null;
		ArrayList<Cliente> clienti = null;
		Cliente cliente = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_INFO_CLIENTI_CORSO);
			clienti = new ArrayList<Cliente>();
			ps.setString(1, corso.getNome());
			ps.setDate(2, new Date(corso.getDataInizio().getTimeInMillis()));
			ps.setDate(3, new Date(corso.getDataFine().getTimeInMillis()));
			ps.setBoolean(4, true);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				cliente = new Cliente();
				cliente.setEmail(rs.getString("utenti.Email"));
				clienti.add(cliente);
			}
			
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return clienti;
	}
	
	/**
	 * Metodo che restuisce i nomi dei corsi a cui il cliente, associato all'email passata come
	 * parametro, è iscritto.
	 * @param emailCliente Email del cliente di cui si vogliono conoscere i corsi attivi a cui è iscritto.
	 * @return lista dei nomi dei corsi attivi a cui il cliente è iscritto.
	 * @throws SQLException
	 */
	public static synchronized ArrayList<String> getCorsiCliente(String emailCliente) throws SQLException
	{
		Connection con = null;
		ArrayList<String> nomiCorso= new ArrayList<String>();
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			PreparedStatement ps = con.prepareStatement(GET_CORSI_CLIENTE);
			ps.setString(1, emailCliente);
			ps.setBoolean(2, true);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				String nome = "";
				nome = rs.getString("NomeCorso");
				nomiCorso.add(nome);
			}
			rs.close();
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
			
		return nomiCorso;
	}
	
	private static final String TABELLA_ISCRIZIONE = "palestra.iscrizioni";
	private static final String TABELLA_CORSI = "palestra.corsi";
	private static final String TABELLA_UTENTI = "palestra.utenti";
	private static final String INSERISCI_ISCRIZIONE = "INSERT INTO " + TABELLA_ISCRIZIONE
								+ " VALUES (?, ?, ?, ?)";
	private static final String GET_GUADAGNI = "SELECT Nome,SUM(Costo) FROM "
									+ TABELLA_CORSI + " INNER JOIN " + TABELLA_ISCRIZIONE 
		+ " ON corsi.Nome=iscrizioni.NomeCorso AND corsi.DataInizio=iscrizioni.DataInizioCorso"
		+ " AND corsi.DataFine=iscrizioni.DataFineCorso AND"
		+ " Stato=? GROUP BY Nome";
	private static final String GET_COSTI = "SELECT SUM(corsi.Costo) FROM "
			+ TABELLA_CORSI + " INNER JOIN " + TABELLA_ISCRIZIONE 
		+ " ON corsi.Nome=iscrizioni.NomeCorso AND corsi.DataInizio=iscrizioni.DataInizioCorso"
	  	+ " AND corsi.DataFine=iscrizioni.DataFineCorso"
	  	+ " INNER JOIN " + TABELLA_UTENTI + " ON utenti.Email=iscrizioni.EmailUtente"
	  	+ " WHERE corsi.Stato=? AND utenti.Email=?";
	private static final String GET_CLIENTI_CORSO = 
			"SELECT utenti.Nome,utenti.Cognome,utenti.DataNascita FROM " + TABELLA_UTENTI
	+ " INNER JOIN " + TABELLA_ISCRIZIONE + " ON utenti.Email = iscrizioni.EmailUtente"
						+" WHERE NomeCorso=? AND DataInizioCorso=? AND DataFineCorso=? AND Stato=?";
	private static final String GET_INFO_CLIENTI_CORSO = 
			"SELECT utenti.Email FROM " + TABELLA_UTENTI
	+ " INNER JOIN " + TABELLA_ISCRIZIONE + " ON utenti.Email = iscrizioni.EmailUtente"
						+" WHERE NomeCorso=? AND DataInizioCorso=? AND DataFineCorso=? AND Stato=?";
	private static final String GET_CORSI_CLIENTE =
			"SELECT NomeCorso FROM "+ TABELLA_ISCRIZIONE +
			" INNER JOIN " + TABELLA_CORSI + " ON iscrizioni.NomeCorso=corsi.Nome AND"
			+ " iscrizioni.DataInizioCorso=corsi.DataInizio AND"
			+ " iscrizioni.DataFineCorso=corsi.DataFine"
			+ " WHERE EmailUtente=? AND Stato=? ";
	private static final String GET_DATA_PRIMO_CORSO = 
			"SELECT DataFine FROM " + TABELLA_CORSI + 
			" WHERE DataFine <= ALL(SELECT DataFine FROM " + TABELLA_CORSI +  " )";
}
