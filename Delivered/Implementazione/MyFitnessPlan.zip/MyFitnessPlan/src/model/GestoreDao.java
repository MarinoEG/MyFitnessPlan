package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.GregorianCalendar;
import connessione.DriveManagerConnectionPool;
import bean.Cliente;
import bean.Gestore;

/**
 * Classe che fornisce metodi per le operazioni relative alla tabella utenti del database, in
 * particolare quelle relative ai gestori.
 * @author Marino Iannacchero
 * @version 2.0
 */
public class GestoreDao 
{
	/**
	 * Metodo che permette di disattivare l'account relativo all' oggetto gestore passato
	 * come parametro.
	 * @param gestore Oggetto gestore da disattivare.
	 */
	public static synchronized void eliminaGestore(Gestore gestore) throws SQLException 
	{
		Connection con = null;
		
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
	
			PreparedStatement ps = con.prepareStatement(ELIMINA_GESTORE);
			GestoreDao.getGestore();
			ps.setBoolean(1, false);
			ps.setString(2, gestore.getEmail());
			ps.executeUpdate();
			
			ps.close();
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Restituisce un oggetto Gestore rappresentante il gestore attuale dal sistema.
	 * @return Gestore del sistema.
	 */
	public static synchronized Gestore getGestore() throws SQLException
	{
		Connection con = null;
		Gestore gestore = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
	
			PreparedStatement ps = con.prepareStatement(GET_GESTORE);
			ps.setString(1, "gestore");
			ps.setBoolean(2, true);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				gestore = Gestore.getInstance();
				gestore.setNome(rs.getString("Nome"));
				gestore.setEmail(rs.getString("Email"));
				gestore.setCognome(rs.getString("Cognome"));
				gestore.setPassword(rs.getBytes("Password"));
				Date data_letta = rs.getDate("DataNascita");
				GregorianCalendar data_nascita = new GregorianCalendar();
				data_nascita.setTime(data_letta);
				gestore.setDataNascita(data_nascita);
				gestore.setStato(rs.getBoolean("Stato"));
			}
			
			ps.close();
		
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
		return gestore;
	}
	
	/**
	 * Metodo che permette di rendere il Cliente passato come parametro il nuovo gestore.
	 * @param cliente
	 * @throws SQLException
	 */
	public static synchronized void setGestore(Cliente cliente) throws SQLException
	{
		Connection con = null;
		try 
		{
			con = DriveManagerConnectionPool.getConnection();
	
			PreparedStatement ps = con.prepareStatement(UPDATE_GESTORE);
			ps.setString(1, "gestore");
			ps.setString(2,cliente.getEmail());
	
			ps.executeUpdate();
			
			ps.close();
			
			cliente = new Cliente();
			GestoreDao.getGestore();
			
		}
		catch (SQLException sqlException) 
		{
			throw sqlException;
		}
		finally 
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	
	private static final String TABELLA_UTENTE = "palestra.utenti";
	private static final String ELIMINA_GESTORE = "UPDATE " + TABELLA_UTENTE 
			+ " SET Stato=? WHERE Email=? ";
	private static final String UPDATE_GESTORE = "UPDATE " + TABELLA_UTENTE
			+ " SET Tipo=? WHERE Email=?";
	private static final String GET_GESTORE = "SELECT * FROM " + TABELLA_UTENTE 
			+ " WHERE Tipo=? AND Stato=?";
}
