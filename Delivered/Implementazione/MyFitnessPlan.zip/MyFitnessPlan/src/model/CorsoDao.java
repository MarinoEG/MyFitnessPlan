package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalTime;
import java.sql.Date;
import java.sql.Connection;
import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno.NomeGiorno;
import bean.Giorno;
import connessione.DriveManagerConnectionPool;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Classe che fornisce metodi per le operazioni relative alle tabella corsi e giorni del database.
 * @author Marino Iannacchero
 * @version 2.0
 */
public class CorsoDao 
{
	
	/**
	 * Metodo che permettere di inserire il corso passato come parametro 
	 * con i giorni associati ad esso
	 * nelle tabelle corsi e giorni nel database.
	 * @param corso Corso da inserire nel database.
	 */
	public static synchronized void inserisciCorso(Corso corso)throws SQLException
	{
		Connection con = null;
		try
		{
			String tipo = "";
			if(corso.getTipo()==Tipo.MENSILE)
			{
				tipo = "MENSILE";
			}
			else if(corso.getTipo()==Tipo.TRIMESTRALE)
			{
				tipo = "TRIMESTRALE";
			}
			else if(corso.getTipo()==Tipo.SEMESTRALE)
			{
				tipo = "SEMESTRALE";
			}
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERISCI_CORSO);
			ps.setString(1, corso.getNome());
			ps.setDate(2, new Date((corso.getDataInizio().getTimeInMillis())));
			ps.setDate(3, new Date((corso.getDataFine().getTimeInMillis())));
			ps.setString(4, tipo);
			ps.setDouble(5, corso.getCosto());
			ps.setBoolean(6, true);
			ps.setInt(7, corso.getEtaConsigliataMin());
			ps.setInt(8, corso.getEtaConsigliataMax());
			ps.setInt(9, corso.getNumMaxIscritti());
			ps.setString(10, corso.getNomeIstruttore());

			
			ps.executeUpdate();
			ps.close();
			HashSet<Giorno> giorniCorso = new HashSet<Giorno>();
			giorniCorso =(HashSet<Giorno>) corso.getGiorniCorso();
			Iterator<Giorno> it;
			it = giorniCorso.iterator();
			Giorno giorno = null;
			giorno = new Giorno();
			while (it.hasNext())
			{
					ps = con.prepareStatement(INSERISCI_GIORNO);
					giorno = it.next();
					giorno.setCorso(corso);
					String nomeGiorno = "";
					switch(giorno.getNome())
					{
						case LUNEDI :
							nomeGiorno = "LUNEDI";
							break;
						case MARTEDI : 
							nomeGiorno = "MARTEDI";
							break;
						case MERCOLEDI : 
							nomeGiorno = "MERCOLEDI";
							break;
						case GIOVEDI : 
							nomeGiorno = "GIOVEDI";
							break;
						case VENERDI : 
							nomeGiorno = "VENERDI";
							break;
						case SABATO : 
							nomeGiorno = "SABATO";
							break;
						case DOMENICA : 
							nomeGiorno = "DOMENICA";
							break;
						
					}
					ps.setString(1, nomeGiorno);
					ps.setTime(2,Time.valueOf(giorno.getOraInizio()));
					ps.setTime(3,Time.valueOf(giorno.getOraFine()));
					ps.setString(4,giorno.getLuogo());
					ps.setString(5, giorno.getCorso().getNome());
					ps.setDate(6, new Date((giorno.getCorso().getDataInizio().getTimeInMillis())));
					ps.setDate(7, new Date((giorno.getCorso().getDataFine().getTimeInMillis())));
					ps.executeUpdate();
					CorsoDao.aggiornaStatoCorso();
			}
			
			
			ps.close();
		}
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che elimina il corso passato come parametro e i giorni relativi ad esso,
	 * dal database
	 * @param corso Corso da eliminare.
	 */
	public static synchronized void eliminaCorso(Corso corso)throws SQLException
	{
		Connection con = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			PreparedStatement ps = con.prepareStatement(ELIMINA_GIORNI);
			ps.setString(1, corso.getNome());
			ps.setDate(2, new Date((corso.getDataInizio().getTimeInMillis())));
			ps.setDate(3, new Date((corso.getDataFine().getTimeInMillis())));
			
			ps.executeUpdate();
			
			ps.close();
			
			ps = con.prepareStatement(ELIMINA_CORSO);
			
			ps.setString(1, corso.getNome());
			ps.setDate(2, new Date((corso.getDataInizio().getTimeInMillis())));
			ps.setDate(3, new Date((corso.getDataFine().getTimeInMillis())));
		
			
			
			ps.executeUpdate();
			ps.close();
			
			
		}
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che aggiorna lo stato dei corsi presenti nel database, i corsi attivi potranno
	 * passare a inattivi se terminati.
	 * @throws SQLException
	 */
	public static synchronized void aggiornaStatoCorso() throws SQLException
	{
		Connection con = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			
			PreparedStatement ps = con.prepareStatement(AGGIORNA_STATO);
			ps.setBoolean(1, false);
			ps.setDate(2, new Date(new GregorianCalendar().getTimeInMillis()));
			

			
			ps.executeUpdate();
			ps.close();
		}
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che restituisce un oggetto Corso, se presente nel database,
	 * in base ai dati passati come parametri.
	 * @param nome nome del corso.
	 * @param dataInizio oggetto rappresentante la data di inizio del Corso.
	 * @param dataFine oggetto rappresentante la data di fine del Corso.
	 * @return l'oggetto Corso se disponibile.
	 */
	public static synchronized Corso getCorso(String nome,GregorianCalendar dataInizio,GregorianCalendar dataFine) throws SQLException
	{
		Corso corso = null;
		Connection con = null;
		Tipo tipo = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			
			PreparedStatement ps = con.prepareStatement(GET_CORSO);
			ps.setString(1,nome);
			ps.setDate(2, new Date(dataInizio.getTimeInMillis()));
			ps.setDate(3, new Date(dataFine.getTimeInMillis()));
			ps.setBoolean(4, true);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				corso = new Corso();
				if(rs.getString("Tipo").equalsIgnoreCase("MENSILE"))
				{
					tipo = Tipo.MENSILE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("TRIMESTRALE"))
				{
					tipo = Tipo.TRIMESTRALE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("SEMESTRALE"))
				{
					tipo = Tipo.SEMESTRALE;
				}
				corso.setNome(rs.getString("Nome"));
				corso.setNomeIstruttore(rs.getString("NomeIstruttore"));
				corso.setEtaConsigliataMin(rs.getInt("EtaConsigliata1"));
				corso.setEtaConsigliataMax(rs.getInt("EtaConsigliata2"));
				corso.setNumMaxIscritti(rs.getInt("MaxIscritti"));
				corso.setCosto(rs.getDouble("Costo"));
				corso.setTipo(tipo);
				corso.setStato(rs.getBoolean("Stato"));
				Date dataLetta = rs.getDate("DataInizio");
				GregorianCalendar data = new GregorianCalendar();
				data.setTime(dataLetta);
				corso.setDataInizio(data);
				
			}
			rs.close();
			ps.close();
			return corso;
		}
		
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
		
			
	}
	
	/**
	 * Metodo che restituisce i corsi attivi presenti
	 * nel database in base alla stringa inserita come parametro.
	 * @param wordkey stringa rappresentante il nome (o parte) del corso.
	 * @return lista dei corsi il cui nome è simile al parametro wordkey.
	 * @throws SQLException
	 */
	public static synchronized ArrayList<Corso> ricercaCorsi(String wordkey) throws SQLException
	{
		ArrayList<Corso> corsi = null;
		Corso corso = null;
		Connection con = null;
		Tipo tipo = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			corsi = new ArrayList<Corso>();
			PreparedStatement ps = con.prepareStatement(RICERCA_CORSI);
			ps.setString(1,wordkey+"%");
			ps.setBoolean(2, true);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				if(rs.getString("Tipo").equalsIgnoreCase("MENSILE"))
				{
					tipo = Tipo.MENSILE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("TRIMESTRALE"))
				{
					tipo = Tipo.TRIMESTRALE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("SEMESTRALE"))
				{
					tipo = Tipo.SEMESTRALE;
				}
				corso = new Corso();
				corso.setNome(rs.getString("Nome"));
				corso.setNomeIstruttore(rs.getString("NomeIstruttore"));
				corso.setEtaConsigliataMin(rs.getInt("EtaConsigliata1"));
				corso.setEtaConsigliataMax(rs.getInt("EtaConsigliata2"));
				corso.setNumMaxIscritti(rs.getInt("MaxIscritti"));
				corso.setCosto(rs.getDouble("Costo"));
				corso.setStato(rs.getBoolean("Stato"));
				corso.setTipo(tipo);
				Date dataLetta = rs.getDate("DataInizio");
				GregorianCalendar data = new GregorianCalendar();
				data.setTime(dataLetta);
				corso.setDataInizio(data);
				corsi.add(corso);
			}
			rs.close();
			ps.close();
			return corsi;
		}
		
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}	
	
	/**
	 * Metodo che restituisce l'insieme dei giorni del corso inserito come parametro.
	 * @param corso Corso di cui cercare i giorni.
	 * @return L'insieme di giorni associati al corso.
	 */
	public static synchronized HashSet<Giorno> ricercaGiorniCorso(Corso corso) throws SQLException
	{
		Giorno giorno = null;
		HashSet<Giorno> giorni = null;
		Connection con = null;
		NomeGiorno nomeGiorno = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			giorni = new HashSet<Giorno>();
			PreparedStatement ps = con.prepareStatement(RICERCA_GIORNI);
			ps.setString(1,corso.getNome());
			ps.setDate(2, new Date(corso.getDataInizio().getTimeInMillis()));
			ps.setDate(3, new Date(corso.getDataFine().getTimeInMillis()));
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				switch(rs.getString("Nome"))
				{
					case "LUNEDI" : 
						nomeGiorno = NomeGiorno.LUNEDI;
						break;
					case "MARTEDI" : 
						nomeGiorno = NomeGiorno.MARTEDI;
						break;
					case "MERCOLEDI" : 
						nomeGiorno = NomeGiorno.MERCOLEDI;
						break;
					case "GIOVEDI" : 
						nomeGiorno = NomeGiorno.GIOVEDI;
						break;
					case "VENERDI" : 
						nomeGiorno = NomeGiorno.VENERDI;
						break;
					case "SABATO" : 
						nomeGiorno = NomeGiorno.SABATO;
						break;
					case "DOMENICA" : 
						nomeGiorno = NomeGiorno.DOMENICA;
						break;
						
				}
				giorno = new Giorno();
				giorno.setNome(nomeGiorno);
				Time oraILetta = rs.getTime("OrarioInizio");
				LocalTime oraInizio = oraILetta.toLocalTime();	
				giorno.setOraInizio(oraInizio);
				Time oraFLetta = rs.getTime("OrarioFine");
				LocalTime oraFine = oraFLetta.toLocalTime();
				giorno.setOraFine(oraFine);
				giorno.setCorso(corso);
				giorno.setLuogo(rs.getString("Luogo"));
				giorni.add(giorno);
			}
			rs.close();
			ps.close();
			return giorni;
		}
		
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che restituisce la lista dei corsi attivi presenti nel database.
	 * @return Lista dei corsi attivi.
	 */
	public static synchronized ArrayList<Corso> getCorsi() throws SQLException
	{
		ArrayList<Corso> corsi = null;
		Corso corso = null;
		Connection con = null;
		Tipo tipo = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			CorsoDao.aggiornaStatoCorso();
			corsi = new ArrayList<Corso>();
			PreparedStatement ps = con.prepareStatement(GET_CORSI);
			ps.setBoolean(1, true);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				if(rs.getString("Tipo").equalsIgnoreCase("MENSILE"))
				{
					tipo = Tipo.MENSILE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("TRIMESTRALE"))
				{
					tipo = Tipo.TRIMESTRALE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("SEMESTRALE"))
				{
					tipo = Tipo.SEMESTRALE;
				}
				corso = new Corso();
				corso.setNome(rs.getString("Nome"));
				corso.setNomeIstruttore(rs.getString("NomeIstruttore"));
				corso.setEtaConsigliataMin(rs.getInt("EtaConsigliata1"));
				corso.setEtaConsigliataMax(rs.getInt("EtaConsigliata2"));
				corso.setNumMaxIscritti(rs.getInt("MaxIscritti"));
				corso.setCosto(rs.getDouble("Costo"));
				corso.setStato(rs.getBoolean("Stato"));
				corso.setTipo(tipo);
				Date dataLetta = rs.getDate("DataInizio");
				GregorianCalendar data = new GregorianCalendar();
				data.setTime(dataLetta);
				corso.setDataInizio(data);
				corsi.add(corso);
			}
			rs.close();
			ps.close();
			return corsi;
		}
		
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}
	
	/**
	 * Metodo che restituisce l'insieme di tutti i giorni dei corsi attivi presenti nel database.
	 * @return L'insieme dei giorni dei corsi.
	 */
	public static synchronized HashSet<Giorno> getGiorni() throws SQLException
	{
		Giorno giorno = null;
		HashSet<Giorno> giorni = null;
		Connection con = null;
		NomeGiorno nomeGiorno = null;
		Corso corso = null;
		Tipo tipo = null;
		try
		{
			con = DriveManagerConnectionPool.getConnection();
			giorni = new HashSet<Giorno>();
			PreparedStatement ps = con.prepareStatement(GET_GIORNI);
			ps.setBoolean(1, true);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				switch(rs.getString("Nome"))
				{
					case "LUNEDI" : 
						nomeGiorno = NomeGiorno.LUNEDI;
						break;
					case "MARTEDI" : 
						nomeGiorno = NomeGiorno.MARTEDI;
						break;
					case "MERCOLEDI" : 
						nomeGiorno = NomeGiorno.MERCOLEDI;
						break;
					case "GIOVEDI" : 
						nomeGiorno = NomeGiorno.GIOVEDI;
						break;
					case "VENERDI" : 
						nomeGiorno = NomeGiorno.VENERDI;
						break;
					case "SABATO" : 
						nomeGiorno = NomeGiorno.SABATO;
						break;
					case "DOMENICA" : 
						nomeGiorno = NomeGiorno.DOMENICA;
						break;
						
				}
				if(rs.getString("Tipo").equalsIgnoreCase("MENSILE"))
				{
					tipo = Tipo.MENSILE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("TRIMESTRALE"))
				{
					tipo = Tipo.TRIMESTRALE;
				}
				else if(rs.getString("Tipo").equalsIgnoreCase("SEMESTRALE"))
				{
					tipo = Tipo.SEMESTRALE;
				}
				HashSet<Giorno> giorni2 = new HashSet<Giorno>();
				giorno = new Giorno();
				corso = new Corso();
				corso.setNome(rs.getString("NomeCorso"));
				Date dataLetta = rs.getDate("DataInizioCorso");
				GregorianCalendar data = new GregorianCalendar();
				data.setTime(dataLetta);
				corso.setCosto(rs.getDouble("Costo"));
				corso.setTipo(tipo);
				corso.setDataInizio(data);
				corso.setNumMaxIscritti(rs.getInt("MaxIscritti"));
				corso.setEtaConsigliataMin(rs.getInt("EtaConsigliata1"));
				corso.setEtaConsigliataMax(rs.getInt("EtaConsigliata2"));
				corso.setNomeIstruttore(rs.getString("NomeIstruttore"));
				corso.setStato(rs.getBoolean("Stato"));
				giorno.setNome(nomeGiorno);
				Time oraILetta = rs.getTime("OrarioInizio");
				LocalTime oraInizio = oraILetta.toLocalTime();	
				giorno.setOraInizio(oraInizio);
				Time oraFLetta = rs.getTime("OrarioFine");
				LocalTime oraFine = oraFLetta.toLocalTime();
				giorno.setOraFine(oraFine);
				giorno.setCorso(corso);
				giorno.setLuogo(rs.getString("Luogo"));
				giorni.add(giorno);
				giorni2.add(giorno);
				corso.setGiorniCorso(giorni2);
			}
			rs.close();
			ps.close();
			return giorni;
		}
		
		catch(SQLException sqlException)
		{
			throw sqlException;
		}
		finally
		{
			DriveManagerConnectionPool.releaseConnection(con);
		}
	}	
	private static final String TABELLA_CORSI = "palestra.corsi";
	private static final String TABELLA_GIORNI = "palestra.giorni";

	
	private static final String INSERISCI_CORSO = "INSERT INTO " + TABELLA_CORSI
									+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String ELIMINA_CORSO =  "DELETE FROM " + TABELLA_CORSI
									+ " WHERE Nome=? AND DataInizio=? AND DataFine=? ";
	private static final String GET_CORSO = "SELECT * FROM " + TABELLA_CORSI
				+ " WHERE Nome=? AND DataInizio=? AND DataFine=? AND Stato=?";
	private static final String RICERCA_CORSI = "SELECT * FROM " + TABELLA_CORSI
									+ " WHERE Nome LIKE ? "+" AND STATO=?";
	private static final String INSERISCI_GIORNO = "INSERT INTO " + TABELLA_GIORNI 
									+ " VALUES (?, ?, ?, ?, ?, ?, ?)";
	private static final String ELIMINA_GIORNI = "DELETE FROM " + TABELLA_GIORNI 
						+ " WHERE NomeCorso=? AND DataInizioCorso=? AND DataFineCorso=?";
	private static final String RICERCA_GIORNI = "SELECT * FROM " +  TABELLA_GIORNI 
						+ " WHERE NomeCorso=? AND DataInizioCorso=? AND DataFineCorso=?";
	private static final String AGGIORNA_STATO = "UPDATE " + TABELLA_CORSI
									+ " SET stato=?" + " WHERE DataFine <?";
	private static final String GET_CORSI = "SELECT * FROM " + TABELLA_CORSI
									+ " WHERE Stato=?";
	private static final String GET_GIORNI =
	"SELECT * FROM " + TABELLA_GIORNI + " INNER JOIN "+ TABELLA_CORSI + 
	" ON giorni.NomeCorso = corsi.Nome AND giorni.DataInizioCorso = corsi.DataInizio AND giorni.DataFineCorso = corsi.DataFine"+
			" WHERE corsi.Stato=?";
	 
	

}


