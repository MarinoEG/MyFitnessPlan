package exceptions;

/*Eccezione non controllata
 * @author Montefusco Andrea
 */
public class WrongArgumentException extends RuntimeException{

	public WrongArgumentException() {
		super("Argomento errato");
	}
	
	public WrongArgumentException(String msg) {
		super(msg);
	}
}
