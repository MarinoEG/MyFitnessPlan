package bean;

import java.time.LocalTime;

import exceptions.WrongArgumentException;

/**Classe contenente le informazioni di un giorno relativo a un
 * Corso del Sistema.
 * @author Montefusco Andrea
 * @version 2.0
 */
public class Giorno 
{
	/**
	 * Enum che rappresenta i nomi dell' oggetto Giorno.
	 */
	public enum NomeGiorno {
		LUNEDI,
		MARTEDI,
		MERCOLEDI,
		GIOVEDI,
		VENERDI,
		SABATO,
		DOMENICA
	}
	
	private NomeGiorno nome;
	private LocalTime oraInizio;
	private LocalTime oraFine;
	private String luogo;
	private Corso corso;
	
	/**Costruttore utilizzato per istanziare un oggetto Giorno.
	 */
	public Giorno()
	{
		nome = null;
		oraInizio = null;
		oraFine = null;
		luogo = "";
		corso = new Corso();
	}

	/**Costruttore utilizzato per istanziare un oggetto Giorno con parametri 
	 * specifici.
	 * @param nome indica il nome del GiornoBean.
	 * @param oraInizio indica l'ora di inzio del Giorno.
	 * (Pre-condizone: oraInizio.isBefore(oraFine)
	 * 
	 * @param oraFine indica l'ora di fine del Giorno.
	 * (Pre-condizone: oraFine.isAfter(oraInizio)
	 * 
	 * @param luogo indica il luogo del Giorno.
	 * @param corso indica il Corso relativo al Giorno.
	 */
	public Giorno(NomeGiorno nome, LocalTime oraInizio, LocalTime oraFine,
			String luogo, Corso corso) 
	{
		if(!oraInizio.isBefore(oraFine)) throw new WrongArgumentException();
		if(!oraFine.isAfter(oraInizio)) throw new WrongArgumentException();
		
		this.nome = nome;
		this.oraInizio = oraInizio;
		this.oraFine = oraFine;
		this.luogo = luogo;
		this.corso = corso;
	}

	/**Metodo che permette di ottenere il nome del Giorno.
	 * @return restituisce il nome del Giorno se disponibile.
	 */
	public NomeGiorno getNome() 
	{
		return nome;
	}

	/**Metodo che permette di cambiare il nome del Giorno.
	 * @param nome nuovo nome da assegnare al Giorno.
	 */
	public void setNome(NomeGiorno nome) 
	{
		this.nome = nome;
	}

	/**Metodo che permette di ottenere l'ora di inizio del Giorno.
	 * @return restituisce l'ora di inizio del Giorno se disponibile.
	 */
	public LocalTime getOraInizio() 
	{
		return oraInizio;
	}

	/**Metodo che permette di cambiare l'ora di inizio del Giorno.
	 * (Post-condizone: getOraInizio().isBefore(getOraFine()))
	 * @param oraInizio nuova ora di inizio da assegnare al Giorno.
	 * (Pre-condizone: oraInizio.isBefore(getOraFine)
	 */
	public void setOraInizio(LocalTime oraInizio) 
	{
		if(this.oraFine == null)
		{
			this.oraInizio = oraInizio;
		}
		else
		{
			if(!oraInizio.isBefore(getOraFine())) throw new WrongArgumentException();
			
			this.oraInizio = oraInizio;
			
			if(!getOraInizio().isBefore(getOraFine())) throw new WrongArgumentException();
		}
		
	}

	/**Metodo che permette di ottenere l'ora di fine del Giorno.
	 * @return restituisce l'ora di fine del Giorno se disponibile.
	 */
	public LocalTime getOraFine() 
	{
		return oraFine;
	}

	/**Metodo che permette di cambiare l'ora di fine del Giorno.
	 * (Post-condizone: getOraFine().isAfter(getOraInizio())
	 * @param oraInizio nuova ora di fine da assegnare al Giorno.
	 * (Pre-condizone: oraFine.isAfter(getOraInizio)
	 */
	public void setOraFine(LocalTime oraFine) 
	{
		if(this.oraInizio==null)
		{
			this.oraFine=oraFine;
		}
		else
		{
			if(!oraFine.isAfter(getOraInizio())) throw new WrongArgumentException();

			this.oraFine = oraFine;
			
			if(!getOraFine().isAfter(getOraInizio()));
		}
		
	}
	
	/**Metodo che permette di ottenere il luogo del Giorno.
	 * @return restituisce il luogo del Giorno se disponibile.
	 */
	public String getLuogo() 
	{
		return luogo;
	}

	/**Metodo che permette di cambiare il luogo del Giorno.
	 * @param luogo nuovo luogo da assegnare al Giorno.
	 */
	public void setLuogo(String luogo) 
	{
		this.luogo = luogo;
	}

	/**Metodo che permette di ottenere il Corso del Giorno.
	 * @return restituisce il Corso del Giorno se disponibile.
	 */
	public Corso getCorso() 
	{
		return corso;
	}

	/**Metodo che permette di cambiare il Corso del Giorno.
	 * (Post-condizione): nuovoCorso.equals(getCorso())
	 * @param nuovoCorso nuovo Corso da assegnare al Giorno.
	 * (Pre-condizione: !nuovoCorso.equals(getCorso())
	 */
	public void setCorso(Corso nuovoCorso) 
	{
		if(corso != nuovoCorso) {
			Corso vecchioCorso = corso;
			corso = nuovoCorso;
				
			if(nuovoCorso != null)
				nuovoCorso.aggiungiGiorno(this);
				
			if(vecchioCorso != null)
				vecchioCorso.eliminaGiorno(this);
			}
	}
	
	public boolean equals(Object otherObject) 
	{
		
		if(otherObject == null) return false;
		if(getClass() != otherObject.getClass())return false;
		
		Giorno other = (Giorno) otherObject;
		return nome.equals(other.nome) && oraInizio.equals(other.oraInizio) &&
				oraFine.equals(other.oraFine) &&
				luogo.equals(other.luogo) &&
				corso.equals(other.corso);
	}
}
