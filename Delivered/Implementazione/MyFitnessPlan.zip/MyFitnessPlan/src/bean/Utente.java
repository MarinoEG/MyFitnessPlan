package bean;

import java.util.Arrays;
import java.util.GregorianCalendar;

/**Classe astratta contenente le informazioni di un Utente
 * del Sistema.
 * @author Andrea Montefusco.
 * @version 2.0
 */
public abstract class Utente 
{

	private String email;
	private String nome;
	private String cognome;
	private byte[] password;
	private GregorianCalendar dataNascita;
	private boolean stato;
	
	
	/**Costruttore utilizzato dalle sottoclassi per istanziare una sottoclasse
	 * di Utente.
	 */
	public Utente() 
	{
		email = "";
		nome = "";
		cognome = "";
		password = new byte[255];
		dataNascita = new GregorianCalendar();
		stato = true;
	}
	
	/**Costruttore utilizzato dalle sottoclassi per istanziare una sottoclasse
	 * di Utente con parametri specifici.
	 * @param email indica l'email dell'Utente.
	 * @param nome indica il nome dell'Utente.
	 * @param cognome indica il cognome dell'Utente.
	 * @param password indica la password dell'Utente.
	 * @param dataNascita indica la data di nascita dell'Utente.
	 * @param stato indica lo stato(attivo o inattivo) dell'Utente.
	 */
	public Utente(String email,String nome,String cognome,
			byte[] password,GregorianCalendar dataNascita, boolean stato) 
	{
		this.email = email;
		this.nome = nome;
		this.cognome = cognome;
		this.password = password;
		this.dataNascita = dataNascita;
		this.stato=stato;
	}
	
	/**Metodo che permette di ottenere l'email dell'Utente.
	 * @return restituisce l'email dell'Utente se disponibile.
	 */
	public String getEmail() 
	{
		return email;
	}
	
	/**Metodo che permette di cambiare l'email dell'Utente.
	 * @param email nuova email da assegnare all'Utente.
	 */
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	/**Metodo che permette di ottenere il nome dell'Utente.
	 * @return restituisce il nome dell'Utente se disponibile.
	 */
	public String getNome() 
	{
		return nome;
	}
	
	/**Metodo che permette di cambiare il nome dell'Utente.
	 * @param nome nuovo nome da assegnare all'Utente.
	 */
	public void setNome(String nome) 
	{
		this.nome = nome;
	}
	

	/**Metodo che permette di ottenere il cognome dell'Utente.
	 * @return restituisce il cognome dell'Utente se disponibile.
	 */
	public String getCognome() 
	{
		return cognome;
	}
	
	/**Metodo che permette di cambiare il cognome dell'Utente.
	 * @param cognome nuovo cognome da assegnare all'Utente.
	 */
	public void setCognome(String cognome) 
	{
		this.cognome = cognome;
	}
	
	/**Metodo che permette di ottenere la password dell'Utente.
	 * @return restituisce la password dell'Utente se disponibile.
	 */
	public byte[] getPassword() 
	{
		return password;
	}
	
	/**Metodo che permette di cambiare la password dell'Utente.
	 * @param password nuova password da assegnare all'Utente.
	 */
	public void setPassword(byte[] password) 
	{
		this.password = password;
	}
	
	/**Metodo che permette di ottenere la data di nascita dell'Utente.
	 * @return restituisce un oggetto GregorianCalendar contenente la data di
	 * nascita dell'Utente.
	 */
	public GregorianCalendar getDataNascita()
	{
		return dataNascita;
	}
	
	/**Metodo che permette di cambiare la data di nascita dell'Utente.
	 * @param dataNascita oggetto GregorianCalendar rappresentante la data
	 * di nascita dell'Utente.
	 */
	public void setDataNascita(GregorianCalendar dataNascita) 
	{
		this.dataNascita = dataNascita;
	}
	
	/**Metodo che permette di ottenere lo stato dell'Utente.
	 * @return restituisce true o false in base allo stato dell'Utente
	 */
	public boolean getStato()
	{
		return stato;
	}
	
	/**Metodo che permette di cambiare lo stato dell'Utente.
	 * @param stato oggetto boolean rappresentante lo stato dell'utente.
	 */
	 
	public void setStato(boolean stato)
	{
		this.stato = stato;
	}
	 
	public boolean equals(Object otherObject)
	{
		if(otherObject == null) return false;
		if(getClass() != otherObject.getClass())return false;
		Utente other = (Utente) otherObject;
		return email.equals(other.email) && nome.equals(other.nome) &&
				cognome.equals(other.cognome) &&
				Arrays.equals(password, other.password) &&
				dataNascita.equals(dataNascita) && 
				stato==other.stato ;
	}
}
