package bean;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import exceptions.WrongArgumentException;

/**Classe contenente le informazioni di un corso del Sistema.
 * @author Andrea Montefusco.
 * @version 2.0
 */
public class Corso 
{
	/**
	 * Enum che rappresenta le tipologie dell' oggetto Corso.
	 */
	public enum Tipo 
	{
		MENSILE,
		TRIMESTRALE,
		SEMESTRALE
	}

	private String nome;
	private Tipo tipo;
	private GregorianCalendar dataInizio;
	private GregorianCalendar dataFine;
	private double costo;
	private boolean stato;
	private int numMaxIscritti;
	private int etaConsigliataMin;
	private int etaConsigliataMax;
	private String nomeIstruttore;
	private List<Cliente> clientiIscritti;
	private Set<Giorno> giorniCorso;

	/**Costruttore utilizzato per istanziare un oggetto Corso.
	 */
	public Corso()
	{
		nome = "";
		tipo = null;
		dataInizio = null;
		dataFine = null;
		costo = 0;
		stato = false;
		numMaxIscritti = 0;
		etaConsigliataMin = 0;
		etaConsigliataMax = 999;
		nomeIstruttore = "";
		clientiIscritti = new ArrayList<Cliente>();
		giorniCorso = new HashSet<Giorno>();
	}
	
	/**Costruttore utilizzato per istanziare un oggetto Corso con parametri 
	 * specifici, viene fornita una data di inizio e viene definita una data
	 * di fine in base al paramentro tipo.
	 * Tipo MENSILE data fine 30 giorni dopo la data di inizio.
	 * Tipo TRIMESTRALE data fine 90 giorni dopo la data di inizio.
	 * Tipo SEMESTRALE data fine 180 giorni dopo la data di inizio.
	 * @param nome indica il nome del Corso.
	 * @param tipo indica la tipologia del Corso.
	 * @param data_inizio indica la data di inizio del Corso.
	 * @param data_fine indica la data di fine del Corso.
	 * @param costo indica il costo del Corso.
	 * @param stato indica lo stato del Corso.
	 * @param num_max_iscritti indica il numero massimo di iscritti al Corso.
	 * (Pre-condizione: numMaxIscritti >= 0)
	 * 
	 * @param etaConsigliataMin indica l'età minima consigliata del Corso.
	 * (Pre-condizione: etaConsigliataMin >= 0 &&
	 * etaConsigliataMin <= etaConsigliataMax())
	 * 
	 * @param eta_consigliata_max indica l'età massima consigliata del Corso.
	 * (Pre-condizione: etaConsigliataMax >= etaConsigliataMin())
	 *  
	 * @param nomeIstruttore indica il nome dell'istruttore del Corso.
	 * @param luogo indica il luogo del Corso.
	 * @param clientiIscritti lista di Cliente iscritti al Corso.
	 * @param giorniCorso insieme di Giorno in cui si tiene il Corso.
	 * (Pre-condizione: giorniCorso.size() <= 6) 
	 */
	public Corso(String nome, Tipo tipo, GregorianCalendar dataInizio,
			double costo, boolean stato, int numMaxIscritti,
			int etaConsigliataMin,int etaConsigliataMax,
			String nomeIstruttore,List<Cliente> clientiIscritti,
			HashSet<Giorno> giorniCorso) 
	{
		if(numMaxIscritti < 0) throw new WrongArgumentException();
		if(etaConsigliataMin < 0 || etaConsigliataMin > etaConsigliataMax)
			throw new WrongArgumentException();
		
		if(giorniCorso != null)
			if(giorniCorso.size() > 6) throw new WrongArgumentException();
		
		this.nome = nome;
		this.tipo = tipo;
		this.dataInizio = dataInizio;
		
		if(tipo == null)
			throw new WrongArgumentException();
		
		if(tipo == Tipo.MENSILE)
		this.dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR), 
				dataInizio.get(Calendar.MONTH),
				dataInizio.get(Calendar.DAY_OF_MONTH) + 30);
		
		if(tipo == Tipo.TRIMESTRALE)
			this.dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR), 
					dataInizio.get(Calendar.MONTH),
					dataInizio.get(Calendar.DAY_OF_MONTH) + 90);
		
		if(tipo == Tipo.SEMESTRALE)
			this.dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR), 
					dataInizio.get(Calendar.MONTH),
					dataInizio.get(Calendar.DAY_OF_MONTH) + 180);
		
		this.costo = costo;
		this.stato = stato;
		this.numMaxIscritti = numMaxIscritti;
		this.etaConsigliataMin = etaConsigliataMin;
		this.etaConsigliataMax = etaConsigliataMax;
		this.nomeIstruttore = nomeIstruttore;
		this.clientiIscritti = clientiIscritti;
		this.giorniCorso = giorniCorso;
	}
	
	/**Metodo che permette di ottenere la data di inizio del Corso.
	 * @return restituisce la data di inizio del Corso se disponibile.
	 */
	public GregorianCalendar getDataInizio() 
	{
		return dataInizio;
	}
	
	/**Metodo che permette di settare la data d'inizio del Corso e in base al tipo
	 * anche la data di fine.
	 * (Pre-condizione) getTipo()!=null
	 * @param dataInizio nuova data di inizio da assegnare al Corso.
	 */
	public void setDataInizio(GregorianCalendar dataInizio)
	{
		if(this.dataInizio==null && this.dataFine==null )
		{
			this.dataInizio=dataInizio;
			if(tipo==Tipo.MENSILE)
			{
				GregorianCalendar dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR),dataInizio.get(Calendar.MONTH),dataInizio.get(Calendar.DAY_OF_MONTH)+30);
				this.dataFine = dataFine;
			}
			
			if(tipo==Tipo.TRIMESTRALE)
			{
				GregorianCalendar dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR),dataInizio.get(Calendar.MONTH),dataInizio.get(Calendar.DAY_OF_MONTH)+90);
				this.dataFine = dataFine;
			}
			
			if(tipo==Tipo.SEMESTRALE)
			{
				GregorianCalendar dataFine = new GregorianCalendar(dataInizio.get(Calendar.YEAR),dataInizio.get(Calendar.MONTH),dataInizio.get(Calendar.DAY_OF_MONTH)+180);
				this.dataFine = dataFine;
			}
			
		}
		
		else
		{
			throw new WrongArgumentException();
		}
		
	}
		
		
	
	/**Metodo che permette di ottenere la data di fine del Corso.
	 * @return restituisce la data di fine del Corso se disponibile.
	 */
	
	public GregorianCalendar getDataFine()
	{
		return dataFine;
	}
	
	/**Metodo che permette di settare la data di fine del Corso
	 * e anche la data di inizio in base al tipo.
	 * (Pre-Condizione) getTipo()!=null
	 * @param dataFine nuova data di fine da assegnare al Corso.
	 */
	public void setDataFine(GregorianCalendar dataFine)
	{

		if(this.dataInizio==null && this.dataFine==null )
		{
			this.dataFine=dataFine;
			
			if(tipo==Tipo.MENSILE)
			{
				GregorianCalendar dataInizio = new GregorianCalendar(dataFine.get(Calendar.YEAR),dataFine.get(Calendar.MONTH),dataFine.get(Calendar.DAY_OF_MONTH)-30);
				this.dataInizio = dataInizio;
			}
			
			if(tipo==Tipo.TRIMESTRALE)
			{
				GregorianCalendar dataInizio = new GregorianCalendar(dataFine.get(Calendar.YEAR),dataFine.get(Calendar.MONTH),dataFine.get(Calendar.DAY_OF_MONTH)-90);
				this.dataInizio = dataInizio;
			}
			
			if(tipo==Tipo.SEMESTRALE)
			{
				GregorianCalendar dataInizio = new GregorianCalendar(dataFine.get(Calendar.YEAR),dataFine.get(Calendar.MONTH),dataFine.get(Calendar.DAY_OF_MONTH)-180);
				this.dataInizio = dataInizio;
			}
						
		}
		
		else
		{
			throw new WrongArgumentException();
		}
	}
	
	/**Metodo che permette di ottenere il nome del Corso.
	 * @return restituisce il nome del Corso se disponibile.
	 */
	public String getNome() 
	{
		return nome;
	}

	/**Metodo che permette di cambiare il nome del Corso.
	 * @param nome nuovo nome da assegnare al Corso.
	 */
	public void setNome(String nome) 
	{
		this.nome = nome;
	}

	/**Metodo che permette di ottenere il tipo del Corso.
	 * @return restituisce il tipo del Corso se disponibile.
	 */
	public Tipo getTipo() 
	{
		return tipo;
	}

	/**Metodo che permette di cambiare il tipo del Corso.
	 * @param tipo nuovo tipo da assegnare al Corso.
	 */
	public void setTipo(Tipo tipo) 
	{
		this.tipo = tipo;
	}
	/**Metodo che permette di ottenere il costo Corso.
	 * @return restituisce il costo del Corso.
	 */
	public double getCosto() 
	{
		return costo;
	}

	/**Metodo che permette di cambiare il costo del Corso.
	 * (Post-condizione: getCosto() >= 0)
	 * @param costo nuovo costo da assegnare al Corso.
	 * (Pre-condizione: costo >= 0)
	 */
	public void setCosto(double costo)
	{
		if(costo < 0) throw new WrongArgumentException();
		
		this.costo = costo;
		
		if (getCosto() < 0) throw new WrongArgumentException();
	}

	/**Metodo che permette di ottenere lo stato del Corso.
	 * @return restituisce true se il Corso è attivo,
	 * false altrimenti.
	 */
	public boolean getStato()
	{
		return stato;
	}

	/**Metodo che permette di cambiare lo stato del Corso.
	 * @param stato nuovo stato da assegnare al Corso.
	 */
	public void setStato(boolean stato)
	{
		this.stato = stato;
	}

	/**Metodo che permette di ottenere il numero massimo di iscritti del Corso.
	 * @return restituisce il numero massimo di iscritti del Corso.
	 */
	public int getNumMaxIscritti() 
	{
		return numMaxIscritti;
	}

	/**Metodo che permette di cambiare il numero massimo di iscritti del Corso.
	 * (Post-condizione: getNumMaxIscritti >= 0)
	 * @param numMaxIscritti nuovo numero massimo di iscritti da assegnare al Corso.
	 * (Pre-condizione: numMaxIscritti >= 0)
	 */
	public void setNumMaxIscritti(int numMaxIscritti)
	{
		if(numMaxIscritti < 0) throw new WrongArgumentException();
			
		this.numMaxIscritti = numMaxIscritti;
		
		if(getNumMaxIscritti() < 0) throw new WrongArgumentException();
	}

	/**Metodo che permette di ottenere l'età consigliata minima del Corso.
	 * @return restituisce l'età consigliata minima del Corso.
	 */
	public int getEtaConsigliataMin() 
	{
		return etaConsigliataMin;
	}

	/**Metodo che permette di cambiare l'età consigliata minima del Corso.
	 * (Post-condizione: getEtaConsigliataMin >= 0 &&
	 * getEtaConsigliataMin() <= getEtaConsigliataMax())
	 * @param etaConsigliataMin nuova età consigliata minima da assegnare al Corso.
	 * (Pre-condizione: etaConsigliataMin >= 0 &&
	 * etaConsigliataMin <= getEtaConsigliataMax()
	 */
	public void setEtaConsigliataMin(int etaConsigliataMin)
	{
		if(etaConsigliataMin < 0 || etaConsigliataMin > getEtaConsigliataMax())
			throw new WrongArgumentException();
		
		this.etaConsigliataMin = etaConsigliataMin;
		
		if(getEtaConsigliataMin() < 0 || getEtaConsigliataMin() >= getEtaConsigliataMax())
			throw new WrongArgumentException();
	}

	/**Metodo che permette di ottenere l'età consigliata massima del Corso.
	 * @return restituisce l'età consigliata massima del Corso.
	 */
	public int getEtaConsigliataMax() 
	{
		return etaConsigliataMax;
	}

	/**Metodo che permette di cambiare l'età consigliata massima del Corso.
	 * (Post-condizione: getEtaConsigliataMax() >= getEtaConsigliataMin())
	 * @param etaConsigliataMax nuova età consigliata massima da assegnare al Corso.
	 * (Pre-condizione: etaConsigliataMax >= getEtaConsigliataMin()
	 */
	public void setEtaConsigliataMax(int etaConsigliataMax) 
	{
		if(etaConsigliataMax < getEtaConsigliataMin())
			throw new WrongArgumentException();
		
		this.etaConsigliataMax = etaConsigliataMax;
		
		if(getEtaConsigliataMax() < getEtaConsigliataMin())
			throw new WrongArgumentException();
	}
	
	/**Metodo che permette di ottenere il nome dell'istruttore del Corso.
	 * @return restituisce il nome dell'istruttore del Corso.
	 */
	public String getNomeIstruttore() 
	{
		return nomeIstruttore;
	}

	/**Metodo che permette di cambiare il nome dell'istruttore del Corso.
	 * @param nome_istruttore nuovo nome dell'istruttore da assegnare al Corso.
	 */
	public void setNomeIstruttore(String nomeIstruttore) 
	{
		this.nomeIstruttore = nomeIstruttore;
	}
	
	/**Metodo che permette di ottenere la lista di ClienteBean iscritti al Corso.
	 * @return restituisce la lista di ClienteBean iscritti al Corso.
	 */
	public List<Cliente> getClientiIscritti() 
	{
		return clientiIscritti;
	}

	/**Metodo che permette di cambiare la lista di ClienteBean iscritti al Corso.
	 * @param clienti_iscritti nuovo lista di ClienteBean iscritti da assegnare al Corso.
	 */
	public void setClientiIscritti(List<Cliente> clientiIscritti) 
	{
		this.clientiIscritti = clientiIscritti;
	}

	/**Metodo che permette di ottenere l'insieme di GiornoBean in cui si 
	 * tiene il Corso.
	 * @return restituisce l'insieme di Giorno in cui si tiene il Corso.
	 */
	public Set<Giorno> getGiorniCorso() 
	{
		return giorniCorso;
	}

	/**Metodo che permette di cambiare l'insieme di GioenoBean in cui si
	 * tiene il Corso.
	 * (Post-condizione: getGiorni_corso().size <= 6)
	 * @param giorniCorso nuovo insieme di Giorno in cui si tiene il corso
	 * da assegnare al Corso.
	 * (Pre-condizione: giorni_corso.size <= 6)
	 */
	public void setGiorniCorso(Set<Giorno> giorniCorso) 
	{
		if(giorniCorso.size() > 6)
			throw new WrongArgumentException();
		
		this.giorniCorso = giorniCorso;
		
		if(getGiorniCorso().size() > 6)
			throw new WrongArgumentException();
	}
	
	/**Metodo che aggiunge un nuovo Cliente alla lista dei clienti del Corso,
	 * aggiungendo poi il Corso alla lista dei corsi a cui è 
	 * iscritto il Cliente.
	 * (Post-condizione: isClienteIscritto(cliente))
	 * @param cliente indica il Cliente iscrittosi al Corso.
	 * (Pre-condizione: !isClienteIscritto(cliente))
	 */
	public void aggiungiClienteIscritto(Cliente cliente)
	{
		if(!isClienteIscritto(cliente)) {
		
			clientiIscritti.add(cliente);
			cliente.aggiungiCorsoIscritto(this);
	
		}
	}
	
	/**Metodo che rimuove un Cliente dalla lista dei clienti del Corso,
	 * rimuovendo poi il Corso dalla lista dei corsi a cui è 
	 * iscritto il Cliente.
	 * (Post-condizione: !isClienteIscritto(cliente))
	 * @param cliente indica il Cliente rimosso dal Corso.
	 * (Pre-condizione: isClienteIscritto(cliente))
	 */
	public void eliminaClienteIscritto(Cliente cliente)
	{
		if(isClienteIscritto(cliente)) {
			clientiIscritti.remove(cliente);
			cliente.eliminaCorsoIscritto(this);
		}
	}
	
	/**Metodo che verifica se un Cliente è iscritto a uno specifico Corso, confrontando l'email.
	 * @param cliente indica il Cliente su cui effettuare la verifica.
	 * @return true se il Cliente è contenuto nella lista dei clienti
	 * iscritti al Corso, restituisce false altrimenti.
	 */
	public boolean isClienteIscritto(Cliente cliente)
	{
		for(Cliente c : clientiIscritti)
			if(c.getEmail().equalsIgnoreCase(cliente.getEmail()))
				return true;
		
		return false;
		
	}
	
	/**Metodo che aggiunge un nuovo Giorno all'insieme dei giorni del Corso,
	 * aggiungendo poi il riferimento al Corso in Giorno.
	 * (Post-condizione: isGiornoCorso(giorno) &&
	 * getGiorni_corso.size <= 6)
	 * @param giorno indica il Giorno in cui si tiene il Corso.
	 * (Pre-condizione: !isGiornoCorso(giorno) &&
	 * getGiorni_corso.size() < 6)
	 */
	public void aggiungiGiorno(Giorno giorno)
	{
		if(!isGiornoCorso(giorno) && (getGiorniCorso().size() < 6)) {
			giorniCorso.add(giorno);
			giorno.setCorso(this);
		}
	}
	
	/**Metodo che rimuove un Giorno dall' insieme dei giorni del Corso,
	 * rimuovendo poi il riferimento al Corso in Giorno.
	 * (Post-condizione): !isGiornoCorso(giorno)
	 * @param giorno indica il Giorno da rimuovere dal Corso.
	 * (Pre-condizione: isGiornoCorso(giorno))
	 */
	public void eliminaGiorno(Giorno giorno)
	{
		if(isGiornoCorso(giorno)) {
			giorniCorso.remove(giorno);
			giorno.setCorso(null);
		}
	}
	
	/**Metodo che verifica se un Giorno appartiene all'insieme di uno 
	 * specifico Corso.
	 * @param giorno indica il Giorno su cui effettuare la verifica.
	 * @return true se il Giorno è contenuto nell'insieme dei giorni in cui
	 * si tiene il Corso, restituisce false altrimenti.
	 */
	public boolean isGiornoCorso(Giorno giorno)
	{
		if(giorniCorso.contains(giorno))
			return true;
		
		return false;
	}
	
	public boolean equals(Object otherObject) 
	{
		
		if(otherObject == null) return false;
		if(getClass() != otherObject.getClass())return false;
		
		Corso other = (Corso) otherObject;
		return nome.equals(other.nome) && tipo == other.tipo &&
				dataInizio.equals(other.dataInizio) &&
				dataFine.equals(other.dataFine) &&
				costo == other.costo &&
				stato == other.stato &&
				numMaxIscritti == other.numMaxIscritti &&
				etaConsigliataMin == other.etaConsigliataMin &&
				etaConsigliataMax == other.etaConsigliataMax &&
				nomeIstruttore.equals(other.nomeIstruttore) &&
				clientiIscritti.equals(other.clientiIscritti) &&
				giorniCorso.equals(other.giorniCorso);
	
	}
}