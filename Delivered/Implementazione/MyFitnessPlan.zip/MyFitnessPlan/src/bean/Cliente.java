package bean;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

/**Sottoclasse di Utente contenente le informazioni di un Cliente
 * del Sistema.
 * @author Andrea Montefusco.
 * @version 2.0
 */
public class Cliente extends Utente
{
	
	private List<Corso> corsiIscritto;
	
	/**Costruttore utilizzato per istanziare un oggetto Cliente.
	 */
	public Cliente()
	{
		super();
		corsiIscritto = new ArrayList<Corso>();
	}
	
	/**Costruttore utilizzato per istanziare un oggetto Cliente con parametri
	 * specifici.
	 * @param email indica l'email dell'Utente.
	 * @param nome indica il nome dell'Utente.
	 * @param cognome indica il cognome dell'Utente.
	 * @param password indica la password dell'Utente.
	 * @param dataNascita indica la data di nascita dell'Utente.
	 * @param corsiIscritto indica la lista di CorsiBean rappresentante i corsi
	 * a cui il Cliente è iscritto.
	 * @param stato indica lo stato (attivo o inattivo) del corso.
	 */
	public Cliente(String email,String nome,String cognome,
			byte[] password,GregorianCalendar dataNascita,
			List<Corso> corsiIscritto,boolean stato) 
	{
		super(email, nome, cognome, password, dataNascita,stato);
		this.corsiIscritto = corsiIscritto;
	}
	
	@Override
	public String getEmail() 
	{
		return super.getEmail();
	}

	@Override
	public void setEmail(String email) 
	{
		super.setEmail(email);
	}

	@Override
	public String getNome() 
	{
		return super.getNome();
	}

	@Override
	public void setNome(String nome) 
	{
		super.setNome(nome);
	}

	@Override
	public String getCognome() 
	{
		return super.getCognome();
	}

	@Override
	public void setCognome(String cognome) 
	{
		super.setCognome(cognome);
	}

	@Override
	public byte[] getPassword()
	{
		return super.getPassword();
	}

	@Override
	public void setPassword(byte[] password)
	{
		super.setPassword(password);
	}

	@Override
	public GregorianCalendar getDataNascita() 
	{
		return super.getDataNascita();
	}

	@Override
	public void setDataNascita(GregorianCalendar dataNascita) 
	{
		super.setDataNascita(dataNascita);
	}

	@Override
	public boolean getStato()
	{
		return super.getStato();
	}
	
	@Override
	public void setStato(boolean stato)
	{
		super.setStato(stato);
	}
	
	/**Metodo che aggiunge un nuovo Corso alla lista dei corsi del Cliente,
	 * aggiungendo poi il Cliente alla lista dei clienti iscritti al Corso.
	 * (Post-condizione: isIscritto(corso))
	 * @param corso indica il corso a cui si è iscritto il Cliente.
	 * (Pre-condizione: !isIscritto(corso))
	 */
	public void aggiungiCorsoIscritto(Corso corso)
	{
		if(!isIscritto(corso)) 
		{
			corsiIscritto.add(corso);
			corso.aggiungiClienteIscritto(this);
		}
		
	}
	
	/**Metodo che rimuove un Corso dalla lista dei corsi del Cliente,
	 * rimuovendo poi il Cliente dalla lista dei clienti iscritti al Corso.
	 * (Post-condizione: !isIscritto(corso))
	 * @param corso indica il corso da cui è rimosso il Cliente.
	 * (Pre-condizione: isIscritto(corso))
	 */
	public void eliminaCorsoIscritto(Corso corso)
	{
		if(isIscritto(corso)) 
		{
			corsiIscritto.remove(corso);
			corso.eliminaClienteIscritto(this);
		}
	}
	
	/**Metodo che verifica se un Cliente è iscritto a uno specifico Corso.
	 * @param corso indica il corso su cui effettuare la verifica.
	 * @return true se il Corso è contenuto nella lista dei corsi a cui è
	 * iscritto il Cliente, restituisce false altrimenti.
	 */
	public boolean isIscritto(Corso corso)
	{
		if(corsiIscritto.contains(corso))
			return true;
		
		return false;
	}
	
	public boolean equals(Object otherObject) 
	{
		if(!super.equals(otherObject)) return false;
		
		Cliente other = (Cliente) otherObject;
		
		return corsiIscritto.equals(other.corsiIscritto);
	}
}