package bean;

import java.util.GregorianCalendar;

/**Sottoclasse di Utente contenente le informazioni del Gestore
 * del Sistema.
 * @author Andrea Montefusco.
 * @version 2.0
 */
public class Gestore extends Utente 
{

	private static Gestore gestore = null;
	
	/**Costruttore privato che permette la creazione di un nuovo Gestore.
	 */
	private Gestore()
	{
		super();
	}
	
	/**Metodo statico che permette di ottenere l'istanza di Gestore.
	 * @return oggetto Gestore istanziato.
	 */
	public static Gestore getInstance()
	{
		if(gestore == null)
		{
			gestore = new Gestore();
		}
		return gestore;
	}

	@Override
	public String getEmail() 
	{
		return super.getEmail();
	}

	@Override
	public void setEmail(String email) 
	{
		super.setEmail(email);
	}

	@Override
	public String getNome() 
	{
		return super.getNome();
	}

	@Override
	public void setNome(String nome) 
	{
		super.setNome(nome);
	}

	@Override
	public String getCognome() 
	{
		return super.getCognome();
	}

	@Override
	public void setCognome(String cognome) 
	{
		super.setCognome(cognome);
	}

	@Override
	public byte[] getPassword() 
	{
		return super.getPassword();
	}

	@Override
	public void setPassword(byte[] password) 
	{
		super.setPassword(password);
	}

	@Override
	public GregorianCalendar getDataNascita() 
	{
		return super.getDataNascita();
	}

	@Override
	public void setDataNascita(GregorianCalendar dataNascita) 
	{
		super.setDataNascita(dataNascita);
	}
	
	@Override 
	public boolean getStato()
	{
		return super.getStato();
	}
	
	@Override
	public void setStato(boolean stato)
	{
		super.setStato(stato);
	}
}