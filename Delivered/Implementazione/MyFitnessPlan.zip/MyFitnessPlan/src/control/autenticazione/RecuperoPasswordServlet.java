package control.autenticazione;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import model.ClienteDao;
import utils.EncryptionFacade;
import utils.SendMailTLSFacade;

/**
 * Servlet implementation class recuperoPassword
 */
@WebServlet("/RecuperoPasswordServlet")
public class RecuperoPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecuperoPasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=request.getParameter("email");
		Cliente cliente;
		try {
			cliente = ClienteDao.getCliente(email);
			if(cliente!=null) {
				EncryptionFacade ef = new EncryptionFacade("C:\\Users\\simon\\Desktop\\CARTELLA\\users.dat");
				String password = ef.decrypt(email, cliente.getPassword());
				boolean flag= SendMailTLSFacade.sendMail(email, cliente.getNome(),password);
				if(flag) {
					String conferma="l'email e' stata inviata.";
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginconferma.jsp?conferma="+conferma);
					dispatcher.forward(request, response);
				
				}else {
					String errore="l'email non e' stata inviata";
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
					dispatcher.forward(request, response);
				}
			}
			else {
				String errore="l'email inserita non e' presente nel Database.";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
				dispatcher.forward(request, response);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
				
	}

}
