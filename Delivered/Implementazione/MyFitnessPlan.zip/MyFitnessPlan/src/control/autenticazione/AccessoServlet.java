package control.autenticazione;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Cliente;
import bean.Gestore;
import model.ClienteDao;
import model.GestoreDao;
import model.IscrizioneDao;
import utils.EncryptionFacade;

/**
 * Servlet implementation class AccessoServlet
 */
@WebServlet("/AccessoServlet")
public class AccessoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AccessoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String email = request.getParameter("email");
		String pass = request.getParameter("password");
		PrintWriter out = response.getWriter();

		try {

			EncryptionFacade ef = new EncryptionFacade("C:\\Users\\simon\\Desktop\\CARTELLA\\users.dat");
			byte[] password = ef.encrypt(email, pass);
			ef.save();
			
			Gestore gestore = GestoreDao.getGestore();
			
			if (gestore.getEmail().equals(email) && Arrays.equals(gestore.getPassword(), password)) {
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/AccountGestore/gestionecorsigestore.jsp");
				dispatcher.forward(request, response);
			} else if ((cliente = ClienteDao.getCliente(email)) != null) {
				if (Arrays.equals(cliente.getPassword(), password)) {
					out.println("good");
					HttpSession session = request.getSession(true);
					session.setAttribute("cliente", cliente);
					double costo = IscrizioneDao.getCostiCliente(cliente);
					if(costo == 0) {
						session.setAttribute("costo", "0");
					}
					else {
						session.setAttribute("costo", costo);
					}
					
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/AccountCliente/profilocliente.jsp");
					dispatcher.forward(request, response);
				
				}else {
					String errore= "Password errata";
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
					dispatcher.forward(request, response);
				
				}
			}else {
				String errore= "Email inesistente";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
				dispatcher.forward(request, response);
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	Cliente cliente;
}

