package control.autenticazione;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import model.ClienteDao;
import utils.EncryptionFacade;

/**
 * Servlet implementation class recuperaAccount
 */
@WebServlet("/RipristinaAccountServlet")
public class RipristinaAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RipristinaAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		try {
			List<Cliente> clienti= ClienteDao.getClientiInattivi();
			for(Cliente c: clienti) {
				if(c.getEmail().equals(email)) {
					EncryptionFacade ef = new EncryptionFacade("C:\\Users\\simon\\Desktop\\CARTELLA\\users.dat");
					byte[] pass = ef.encrypt(email, password);
					ClienteDao.ripristinaAccount(email, pass);
				}
			}
			List<Cliente> clientiAttivi= ClienteDao.getClienti();
			boolean flag=false;
			for(Cliente c: clientiAttivi) {
				
				if(c.getEmail().equals(email)) {
					String conferma="account riattivato";
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginconferma.jsp?conferma="+conferma);
					dispatcher.forward(request, response);
					flag=true;
				}
			}
			if(!flag) {
				String errore="errore nella riattivazione dell'account.";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
				dispatcher.forward(request, response);
			}
		} catch (SQLException | InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
