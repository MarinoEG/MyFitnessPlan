package control.accountGestore;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Corso;
import bean.Corso.Tipo;
import bean.Giorno;
import bean.Giorno.NomeGiorno;
import model.CorsoDao;

/**
 * Servlet implementation class InserisciCorso
 */
@WebServlet("/InserisciCorsoServlet")
public class InserisciCorsoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InserisciCorsoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Corso corso = new Corso();
		Boolean giornoCorrect = true;

		String nomeCorso = request.getParameter("nomecorso");
		String nomeIstruttore = request.getParameter("nomeistruttore");
		int etaMin = Integer.parseInt(request.getParameter("etamin"));
		System.out.println(etaMin);
		int etaMax = Integer.parseInt(request.getParameter("etamax"));
		System.out.println(etaMax);
		String maxIscritti = request.getParameter("maxiscritti");
		String tipoCorso = request.getParameter("tipologia");
		Tipo tipo = null;
		if (tipoCorso.equalsIgnoreCase("mensile")) {
			tipo = Tipo.MENSILE;
		} else if (tipoCorso.equalsIgnoreCase("trimestrale")) {
			tipo = Tipo.TRIMESTRALE;
		} else if (tipoCorso.equalsIgnoreCase("semestrale")) {
			tipo = Tipo.SEMESTRALE;
		}
		String data = request.getParameter("datainizio");
		double prezzo = Double.parseDouble(request.getParameter("prezzo"));

		int anno = Integer.parseInt(data.substring(0, 4));
		// System.out.println(anno);
		int mese = Integer.parseInt(data.substring(5, 7));
		// System.out.println(mese);
		int giorno = Integer.parseInt(data.substring(8, 10));
		// System.out.println(giorno);
		GregorianCalendar dataInizio = new GregorianCalendar(anno, mese - 1, giorno);

		String GiornoLunedi = request.getParameter("lunedi");
		String GiornoMartedi = request.getParameter("martedi");
		String GiornoMercoledi = request.getParameter("mercoledi");
		String GiornoGiovedi = request.getParameter("giovedi");
		String GiornoVenerdi = request.getParameter("venerdi");
		String GiornoSabato = request.getParameter("sabato");

		HashSet<Giorno> giorni = new HashSet<>();
		HashSet<Giorno> giorniCorsiDisponibili;
		String errore = " ";
		boolean dataCorrect=false;
		Corso tmp = new Corso();
		tmp.setTipo(tipo);
		tmp.setDataInizio(dataInizio);

		List<Corso> corsi2;
		try {
			corsi2 = CorsoDao.getCorsi();
			for(Corso c: corsi2) {
				if((tmp.getDataInizio().compareTo(c.getDataInizio())>=0 && tmp.getDataInizio().compareTo(c.getDataFine())<=0)
									|| (tmp.getDataFine().compareTo(c.getDataInizio())>=0 && tmp.getDataFine().compareTo(c.getDataFine())<=0)
									|| (tmp.getDataInizio().compareTo(c.getDataInizio())<0 && tmp.getDataFine().compareTo(c.getDataFine())>0))
				
					dataCorrect=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			giorniCorsiDisponibili = CorsoDao.getGiorni();
			if (GiornoLunedi != null) {
				String OrarioInizio = request.getParameter("orainiziolunedi");
				String OrariFine = request.getParameter("orafinelunedi");
				String Luogo = request.getParameter("luogolunedi");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {

					Giorno lunedi = new Giorno(NomeGiorno.LUNEDI, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(lunedi);
					System.out.println(orarioInizio);
					System.out.println(orarioFine);
				}

			}

			if (GiornoMartedi != null) {
				String OrarioInizio = request.getParameter("orainiziomartedi");
				String OrariFine = request.getParameter("orafinemartedi");
				String Luogo = request.getParameter("luogomartedi");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {
					Giorno martedi = new Giorno(NomeGiorno.MARTEDI, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(martedi);
					System.out.println(orarioInizio);
					System.out.println(orarioFine);
				}
			}
			if (GiornoMercoledi != null) {
				String OrarioInizio = request.getParameter("orainiziomercoledi");
				String OrariFine = request.getParameter("orafinemercoledi");
				String Luogo = request.getParameter("luogomercoledi");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {
					Giorno mercoledi = new Giorno(NomeGiorno.MERCOLEDI, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(mercoledi);
					System.out.println(orarioInizio);
					System.out.println(orarioFine);
				}
			}
			if (GiornoGiovedi != null) {
				String OrarioInizio = request.getParameter("orainiziogiovedi");
				String OrariFine = request.getParameter("orafinegiovedi");
				String Luogo = request.getParameter("luogogiovedi");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {

					Giorno giovedi = new Giorno(NomeGiorno.GIOVEDI, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(giovedi);
					System.out.println(orarioInizio);

				}

			}
			if (GiornoVenerdi != null) {
				String OrarioInizio = request.getParameter("orainiziovenerdi");
				String OrariFine = request.getParameter("orafinevenerdi");
				String Luogo = request.getParameter("luogovenerdi");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {
					Giorno venerdi = new Giorno(NomeGiorno.VENERDI, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(venerdi);
					System.out.println(orarioInizio);
					System.out.println(orarioFine);
				}

			}
			if (GiornoSabato != null) {
				String OrarioInizio = request.getParameter("orainiziosabato");
				String OrariFine = request.getParameter("orafinesabato");
				String Luogo = request.getParameter("luogosabato");
				LocalTime orarioInizio = LocalTime.parse(OrarioInizio);
				LocalTime orarioFine = LocalTime.parse(OrariFine);
				for (Giorno x : giorniCorsiDisponibili) {
					if ((x.getLuogo().equals(Luogo)) && ((x.getOraFine().compareTo(orarioFine) == 0)
							&& (x.getOraInizio().compareTo(orarioInizio) == 0)   || (x.getOraInizio().compareTo(orarioInizio)>=0 ||(x.getOraInizio().compareTo(x.getOraFine())<=0))&& dataCorrect)) {
						giornoCorrect = false;
					}
				}
				if (giornoCorrect) {
					Giorno sabato = new Giorno(NomeGiorno.SABATO, orarioInizio, orarioFine, Luogo, corso);
					giorni.add(sabato);
					System.out.println(orarioInizio);
					System.out.println(orarioFine);
				}

			}
			if (giornoCorrect) {
				corso.setCosto(prezzo);
				corso.setNome(nomeCorso);
				corso.setTipo(tipo);
				corso.setDataInizio(dataInizio);
				corso.setEtaConsigliataMin(etaMin);
				corso.setEtaConsigliataMax(etaMax);
				corso.setNomeIstruttore(nomeIstruttore);
				corso.setNumMaxIscritti(Integer.parseInt(maxIscritti));
				corso.setStato(true);
				corso.setGiorniCorso(giorni);
				List<Corso> corsi = CorsoDao.getCorsi();
				System.out.println(corso.getDataFine().getTimeInMillis());
				System.out.println((new GregorianCalendar()).getTimeInMillis());
				if (corso.getDataFine().before(new GregorianCalendar())) {
					errore += "modificare la linea temporale puo' creare gravi danni. E' pregato di inserire un data successiva alla data di oggi";
				}
				if (corsi.size() == 0) {
					CorsoDao.inserisciCorso(corso);
				} else {
					boolean flag = false;
					for (Corso c : corsi) {
						if (c.getNome().equalsIgnoreCase(nomeCorso)) {
							errore += " Corso gia' esistente";
							flag = true;
						}
					}
					if (!flag) {
						CorsoDao.inserisciCorso(corso);
					}
				}
			} else {
				errore += " Giorno e luogo non disponibili";
			}
			RequestDispatcher dispatcher;
			if (errore.equals(" ")) {
				String conferma = "corso inserito correttamente";
				dispatcher = getServletContext()
						.getRequestDispatcher("/Esito/operazionigestoreconferma.jsp?conferma=" + conferma);

			} else {
				dispatcher = getServletContext().getRequestDispatcher("/Esito/operazionigestoreerrore.jsp?errore=" + errore);

			}
			dispatcher.forward(request, response);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
