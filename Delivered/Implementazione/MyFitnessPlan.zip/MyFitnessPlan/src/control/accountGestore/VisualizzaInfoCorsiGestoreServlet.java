package control.accountGestore;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import bean.Corso;
import bean.Giorno;
import model.CorsoDao;
import model.IscrizioneDao;

/**
 * Servlet implementation class visualizzaInfoCorsi
 */
@WebServlet("/VisualizzaInfoCorsiGestoreServlet")
public class VisualizzaInfoCorsiGestoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VisualizzaInfoCorsiGestoreServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nome= request.getParameter("sceltacorso");
		System.out.println(nome);
		try {
			ArrayList<Corso> corsi= CorsoDao.ricercaCorsi(nome);
			
			for(Corso c: corsi) {
					
					Corso corso= c;
					System.out.println(corso.getStato());
					HashSet<Giorno> giorni= CorsoDao.ricercaGiorniCorso(corso);
					ArrayList<Cliente> iscritti = IscrizioneDao.getClientiCorso(corso);
					corso.setClientiIscritti(iscritti);
					for(Giorno g: giorni) {
						System.out.println(g.getNome());
					}
						request.setAttribute("corso", corso);
							System.out.println(corso.getNome() + " "+ corso.getCosto());
								RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/AccountGestore/infocorsogestore.jsp");
								dispatcher.forward(request, response);
			 }
			}catch(

	SQLException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
