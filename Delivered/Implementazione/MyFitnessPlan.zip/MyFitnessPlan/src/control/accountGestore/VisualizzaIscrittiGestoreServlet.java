package control.accountGestore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import model.ClienteDao;

/**
 * Servlet implementation class visualizzaIscrittiGestore
 */
@WebServlet("/VisualizzaIscrittiGestoreServlet")
public class VisualizzaIscrittiGestoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaIscrittiGestoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String packed= "<iscritti>";
		
		try {
			List<Cliente> clienti= ClienteDao.getClienti();
			if(clienti!=null) {
				packed+= "<clienti>";
				for(Cliente c: clienti) {
					
					packed+="<nome>";
					packed+=c.getNome();
					packed+= "</nome>";
					
					packed+="<cognome>";
					packed+= c.getCognome();
					packed+="</cognome>";
					
					packed+="<eta>";
					packed+=c.getDataNascita();
					packed+="</eta>";
				}
				packed+= "</clienti>";
				PrintWriter out= response.getWriter();
				out.write(packed);
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
