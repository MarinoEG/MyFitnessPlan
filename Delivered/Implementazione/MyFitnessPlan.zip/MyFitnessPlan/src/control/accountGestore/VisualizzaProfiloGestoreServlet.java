package control.accountGestore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Gestore;
import model.ClienteDao;
import model.GestoreDao;

/**
 * Servlet implementation class VisualizzaProfiloGestore
 */
@WebServlet("/VisualizzaProfiloGestoreServlet")
public class VisualizzaProfiloGestoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaProfiloGestoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			Gestore gestore= GestoreDao.getGestore();
			String packed= "<informazioni>";
			
			packed+="<nome>";
			packed += gestore.getNome();
			packed += "</nome>";
			
			packed+="<cognome>";
			packed += gestore.getCognome();
			packed += "</cognome>";
			
			packed+="<email>";
			packed += gestore.getEmail();
			packed += "</email>";
			
			packed+="<dataNascita>";
			packed += gestore.getDataNascita().getTime().toLocaleString().substring(0, 11);
			packed += "</dataNascita>";
			
			packed+="<totaleIscritti>";
			packed += ClienteDao.getNumClienti() ;
			packed += "</totaleIscritti>";
			
			packed+= "</informazioni>";
			
			PrintWriter out= response.getWriter();
			out.write(packed);
			out.close();
		
		
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
