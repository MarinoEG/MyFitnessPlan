package control.accountGestore;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import model.ClienteDao;

/**
 * Servlet implementation class visuallizzaSuccessori
 */
@WebServlet("/VisualizzaSuccessoriGestoreServlet")
public class VisualizzaSuccessoriGestoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaSuccessoriGestoreServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String packed= "<clienti>";
		try {
			List<Cliente> clienti= ClienteDao.getClienti();
			if(clienti!=null) {
				for(Cliente c: clienti) {
					packed += "<email>";
					packed += c.getEmail();
					packed += "</email>";
				}
			}
			packed += "</clienti>";
			PrintWriter out= response.getWriter();
			out.write(packed);
			
			out.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
