package control.accountCliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Cliente;
import bean.Corso;
import model.CorsoDao;
import model.IscrizioneDao;

/**
 * Servlet implementation class ricercaCorsi
 */
@WebServlet("/RicercaCorsiServlet")
public class RicercaCorsiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RicercaCorsiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String nome= request.getParameter("nomericerca");
			
			if(nome.equals("")) {
				String packed = "<corsitrovati><nome></nome><stato></stato></corsitrovati>";
				PrintWriter out = response.getWriter();
				out.println(packed);
				out.close();
			}
			else {
				try {
					HttpSession session = request.getSession();
					Cliente cliente = (Cliente) session.getAttribute("cliente");
					List<Corso> corsi = CorsoDao.ricercaCorsi(nome);
					String packed = "<corsitrovati>";
					
					for (Corso c: corsi) {
						packed += "<nome>";
						packed += c.getNome();
						packed += "</nome>";
					
						packed += "<stato>";	
						List<Cliente> clienti= (List<Cliente>)IscrizioneDao.getInfoClientiCorso(c);
					
						if(clienti.size() > 0)
							for(Cliente cl : clienti) {
								if(cl.getEmail().equals(cliente.getEmail()))
									packed+="Iscritto";
								else
									packed+="Non Iscritto";
							}
						else 
							packed+="Non Iscritto";
						
						packed+="</stato>";
					
					}
					
					packed += "</corsitrovati>";
					PrintWriter out= response.getWriter();
					out.println(packed);
					out.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						}
				}
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
