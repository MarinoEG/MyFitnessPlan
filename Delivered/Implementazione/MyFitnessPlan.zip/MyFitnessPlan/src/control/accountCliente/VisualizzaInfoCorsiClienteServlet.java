package control.accountCliente;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import bean.Corso;
import bean.Giorno;
import model.CorsoDao;
import model.IscrizioneDao;

/**
 * Servlet implementation class visuallizzaInfoCorsiCliente
 */
@WebServlet("/VisualizzaInfoCorsiClienteServlet")
public class VisualizzaInfoCorsiClienteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaInfoCorsiClienteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nome= request.getParameter("sceltacorso");
		System.out.println(nome);
		ArrayList<Corso> corsi;
		try {
		
			corsi = CorsoDao.ricercaCorsi(nome);
	
			for(Corso c: corsi) {
				Corso corso= c;
				System.out.println(corso.getStato());
				
				List<Cliente> list = IscrizioneDao.getInfoClientiCorso(corso);
				corso.setClientiIscritti(list);
				HashSet<Giorno> giorni= CorsoDao.ricercaGiorniCorso(corso);
				
				for(Giorno g: giorni) {
					System.out.println(g.getNome());
				}
					request.setAttribute("corso", corso);
						System.out.println(corso.getNome() + " "+ corso.getCosto());
						System.out.println(list.size());
							RequestDispatcher dispatcher= getServletContext().getRequestDispatcher("/AccountCliente/infocorsocliente.jsp");
							dispatcher.forward(request, response);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
