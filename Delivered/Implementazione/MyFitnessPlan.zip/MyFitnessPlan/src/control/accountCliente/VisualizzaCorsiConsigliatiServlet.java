package control.accountCliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Cliente;
import bean.Corso;
import model.CorsoDao;
import model.IscrizioneDao;
import utils.CalendarConverter;

/**
 * Servlet implementation class visualizzaCorsiConsigliati
 */
@WebServlet("/VisualizzaCorsiConsigliatiServlet")
public class VisualizzaCorsiConsigliatiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaCorsiConsigliatiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		GregorianCalendar dataCorrente= new GregorianCalendar();
		HttpSession session= request.getSession();
		Cliente cliente =(Cliente) session.getAttribute("cliente");
		GregorianCalendar dataNascita= cliente.getDataNascita();
		int eta= CalendarConverter.etaConverter(dataCorrente, dataNascita);
		ArrayList<Corso> corsi;
		try {
			String packed = "<corsiconsigliati>";
			corsi = CorsoDao.getCorsi();
			ArrayList<Cliente> list = null;
			
			for(Corso c: corsi) {
				list = IscrizioneDao.getInfoClientiCorso(c);
				c.setClientiIscritti(list);
				if(c.getEtaConsigliataMin()<= eta && eta<=c.getEtaConsigliataMax() ) {
					packed += "<nome>";
					packed += c.getNome();
					packed += "</nome>";
					
					if(c.isClienteIscritto(cliente)) {
						packed += "<stato>";
						packed += "Iscritto";
						packed += "</stato>";
					}
					else {
						packed += "<stato>";
						packed += "Non iscritto";
						packed += "</stato>";
					}
				}
				
			}
			packed += "</corsiconsigliati>";
			PrintWriter out = response.getWriter();
			out.write(packed);
			out.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
