package control.accountCliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.mysql.fabric.xmlrpc.base.Array;

import bean.Cliente;
import bean.Corso;
import model.ClienteDao;
import model.CorsoDao;
import model.IscrizioneDao;

/**
 * Servlet implementation class visualizzaInfoCorsoCliente
 */
@WebServlet("/VisualizzaCorsiIscrittoClienteServlet")
public class VisualizzaCorsiIscrittoClienteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaCorsiIscrittoClienteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session= request.getSession();
		Cliente cliente= (Cliente)session.getAttribute("cliente");
		
		try {
			String packed ="<corsi>";
			ArrayList<String> corsiIscritto= (ArrayList<String>)IscrizioneDao.getCorsiCliente(cliente.getEmail());
			for(String c: corsiIscritto) {
				System.out.println(c);
				packed+="<nome>";
				packed += c; 
				packed += "</nome>";
			}
			packed+= "</corsi>";
			PrintWriter out= response.getWriter();
			out.write(packed);
			out.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
