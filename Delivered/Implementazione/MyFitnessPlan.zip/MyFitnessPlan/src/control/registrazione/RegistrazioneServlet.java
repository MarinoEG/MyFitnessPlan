package control.registrazione;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.GregorianCalendar;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cliente;
import model.ClienteDao;
import utils.EncryptionFacade;

/**
 * Servlet implementation class registrazione
 */
@WebServlet("/RegistrazioneServlet")
public class RegistrazioneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrazioneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nome= request.getParameter("nome");
		String cognome=request.getParameter("cognome");
		
		String dataNascita= request.getParameter("eta"); 	
		int anno=Integer.parseInt(dataNascita.substring(0, 4));
		//System.out.println(anno);
		int mese= Integer.parseInt(dataNascita.substring(5,7));
		//System.out.println(mese);
		int giorno = Integer.parseInt(dataNascita.substring(8,10));//System.out.println(giornoFine);
		GregorianCalendar dataNascitaCliente= new GregorianCalendar(anno, mese-1, giorno);
		
		String email= request.getParameter("email");
		String password= request.getParameter("password");
		
		try {
			if((ClienteDao.getCliente(email))!=null) {
				String errore="email gia' esistente";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginerrore.jsp?errore="+errore);
				dispatcher.forward(request, response);
			
			}else {
				String conferma="registrazione avvenuta con successo";
				Cliente cliente= new Cliente();
				cliente.setNome(nome);
				cliente.setCognome(cognome);
				cliente.setEmail(email);

				EncryptionFacade ef = new EncryptionFacade("C:\\Users\\simon\\Desktop\\CARTELLA\\users.dat");
				cliente.setPassword(ef.encrypt(email, password));
				ef.save();
				
				cliente.setDataNascita(dataNascitaCliente);
				ClienteDao.inserisciUtente(cliente);
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Esito/operazioniloginconferma.jsp?conferma="+conferma);
				dispatcher.forward(request, response);
			
		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
