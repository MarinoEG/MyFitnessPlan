package utils;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**Classe che fornisce metodi statici per operare su data GregorianCalendar.
 * @author Andrea Montefusco
 * @version 1.0
 */
public class CalendarConverter {

	/**Metodo statico che permette di ottenere il numero di anni che intercorrono tra due
	 * date.
	 * @param g1 oggetto che rappresenta la data più recente.
	 * @param g2 oggetto che rappresenta la data più recente.
	 * @return
	 */
	public static int etaConverter(GregorianCalendar g1, GregorianCalendar g2) {
		
		int yd = g1.get(Calendar.YEAR) - g2.get(Calendar.YEAR);
		if (g1.get(Calendar.MONTH) > g2.get(Calendar.MONTH) ||
				(g1.get(Calendar.MONTH) == g2.get(Calendar.MONTH)
				&& g1.get(Calendar.DAY_OF_MONTH) < g2.get(Calendar.DAY_OF_MONTH))) {
		        yd--;
		    }
	
		return yd;
	}
	
}
