package utils;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**Classe che fornisce metodi per l'invio di email a uno specifico utente, contentente la password
 * del suddetto utente.
 * @author andrea
 */
public class SendMailTLSFacade {

	static final String username = "myfitnessplan71@outlook.com";
	static final String password = "Alabama71";
	
	/**
	 * Metodo statico che permette l'invio di una email a uno specifico indirizzo di posta.
	 * @param dest email del destinatario.
	 * @param nome nome del proprietatio dell'email dest.
	 * @param Password password da inviare al proprietario dell'email dest.
	 * @return true se l'email è stata inviata.
	 */
	public static boolean sendMail(String dest, String nome, String Password) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp-mail.outlook.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(dest));
			message.setSubject("Recupero Password");
			message.setText("L'email e' stata generata dal sito MyFitnessPlan per la"
					+ "richiesta di recupero password "
					+ " da parte di" + " " + nome
					+" " + ". La password dell'account e': "  + Password);

			Transport.send(message);

			return true;

		} catch (MessagingException e) {
			throw new RuntimeException(e);
			
		}
		
	}
	
}