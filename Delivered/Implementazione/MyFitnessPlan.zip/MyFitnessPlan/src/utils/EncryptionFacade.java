package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 * Classe che fornisce metodi per crittare/decrittare password. In un file che sarà contenuto in
 * un uno specifico path saranno salvate le coppie SecretKey Email. Non potranno esserci Email
 * uguali.
 * @author Andrea Montefusco.
 * @version 1.0
 */
public class EncryptionFacade {

	private HashMap<String, SecretKey> users;
	private File file;
		
	/**
	 * Costruttore che permette di istanziare/recuperare il file contenente le info da crittare.
	 */
	public EncryptionFacade(String Path) {
					
		file = new File(Path);
				
		if(file.exists()) {
			ObjectInputStream in;
				
			try {
				in = new ObjectInputStream(new FileInputStream(file));
				users = (HashMap<String, SecretKey>) in.readObject();
				in.close();
					
			} catch (IOException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			}
		else {
				
			users = new HashMap<String, SecretKey>();
		}

	}
	
	/**
	 * Metodo che permette di crittare una stringa. La stringa email verrà associata 
	 * a una chiave segreta.
	 * La stringa password sarà convertita in una sequenza di byte in base alla chiave segreta.
	 * @param email email da associare alla chiave segreta.
	 * @param password stringa da crittare.
	 * @return Password convertita in una sequenza di byte in base alle chiave segreta associata
	 * all'email.
	 */
	public byte[] encrypt(String email, String password) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
			
		SecretKey secretKey;
			
		if(users.containsKey(email)) {
			secretKey = users.get(email);
			byte[] encrText = AES.encrypt(password, secretKey);
		        
		    return encrText;
		}
		else {
			secretKey = AES.getSecretKey();
			users.put(email, secretKey);
				
			byte[] encrText = AES.encrypt(password, secretKey);
		    return encrText;
		}
	        
	}
	
	/**
	 * Metodo che permette di decrittare una sequenza di byte. La email verrà associata 
	 * a una chiave segreta.
	 * La sequenza di byte sarà convertita in una stringa in base alla chiave segreta.
	 * @param email email da associare alla chiave segreta.
	 * @param password sequenza di byte da decrittare.
	 * @return Password convertita in una stringa in base alle chiave segreta associata
	 * all'email.
	 */
	public String decrypt(String email, byte[] password) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
			
		SecretKey secretKey;
			
		if(users.containsKey(email)) {
			secretKey = users.get(email);
				
			String decrText = AES.decrypt(password, secretKey);	        
		    return decrText;
		        
		}
		else {
			secretKey = AES.getSecretKey();
			users.put(email, secretKey);
				
			String decrText = AES.decrypt(password, secretKey);	 
				
		    return decrText;
		}
	}
	
	/**
	 * Metodo che permette di aggionare il file aggiungendo le coppie email-chiave segreta generate
	 * dall'ultimo save() (o eventualmente dalla creazione del file).
	 */
	public void save() {
			
		ObjectOutputStream out;
		try {
			out = new ObjectOutputStream(new FileOutputStream(file));
			out.writeObject(users);
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}

