package utils;



import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**Classe che fornisce alcuni metodi statici utilizzabili per crittare/decrittare stringhe in 
 * sequenze di byte secondo la logica dell'algoritmo AES.
 * @author Andrea Montefusco.
 * @version 1.0
 */
public class AES {
	
	/**
	 *Metodo statico che permette di istanziare una chiave che permette di
	 *crittare una stringa. La stessa chiave deve essere utilizzata anche per
	 *decrittare la stringa. La lunghezza della chiave è di 128 bit 
	 * 
	 * @return SecretKey chiave segreta di 128 bit generata.
	 */
	public static SecretKey getSecretKey() throws NoSuchAlgorithmException{
    	
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        generator.init(128);
        SecretKey secretKey = generator.generateKey();
        return secretKey;
    }
	
	/**
	 *Metodo statico che si occupa di crittografare la stringa tramite un oggetto SecretKey.
	 *
	 * @param textToEncrypt Stringa da convertire in sequenza di byte
	 * @param secretKey oggetto che rappresenta la chiave che si utilizzerà per la conversione.
	 * @return La string convertita in byte.
	 */
	public static byte[] encrypt(String textToEncrypt,SecretKey secretKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
    	
        Cipher aesCipher = Cipher.getInstance("AES");
        aesCipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] byteCipherText = aesCipher.doFinal(textToEncrypt.getBytes());
        return byteCipherText;
    }
	
	/**
	 *Metodo statico che si occupa di decrittare la stringa tramite un oggetto SecretKey.
	 *
	 * @param textToEncrypt Stringa da convertire in sequenza di byte
	 * @param secretKey oggetto che rappresenta la chiave che si utilizzerà per la conversione.
	 * @return La string convertita in byte.
	 */
	public static String decrypt(byte[] bytesToDecrypt, SecretKey secretKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
    
        Cipher aesCipher = Cipher.getInstance("AES");
        aesCipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] bytePlainText = aesCipher.doFinal(bytesToDecrypt);
        return new String(bytePlainText);
    }
	
	
	/**
	 *Metodo ausiliario che permette di convertire una sequenza di byte in una
	 *stringa con numeri esadecimali.
	 *
	 * @param sequenza di byte.
	 * @return Stringa con numeri esadecimali.
	 */
	protected static String bytesToHex(byte[] hex) {
    	String sb = "";

    	for (byte b : hex) {
			sb += (Integer.toHexString((int) (b & 0xff)));
		}
    	
    	return sb;
    }
	
}
